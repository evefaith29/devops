<?php

namespace App\Models;

use CodeIgniter\Model;

class PemeliharaanPerawatanModel extends Model
{
    protected $table = 'pemeliharaan_perawatan';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'nama', 'jenis_pemeliharaan', 'jumlah'];

    public function getTotalPengeluaranBulanIni()
    {
        return $this->selectSum('jumlah')
                     ->where('MONTH(tanggal)', date('m'))
                     ->where('YEAR(tanggal)', date('Y'))
                     ->first(); // Mengambil hasil pertama sebagai array
    }
    public function getTotalPengeluaranSeluruhnya()
    {
        return $this->selectSum('jumlah') // Menggunakan selectSum untuk menghitung total
                    ->first(); // Mengambil hasil pertama sebagai array
    }
}
