<?php

namespace App\Models;

use CodeIgniter\Model;

class SPPModel extends Model
{
    protected $table = 'spp';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'nama', 'nama_siswa', 'jumlah_yang_harus_dibayar', 'jumlah_dibayar'];

    public function getTotalPemasukanBulanIni()
    {
        return $this->selectSum('jumlah_dibayar') // Menggunakan selectSum untuk menghitung total
                    ->where('MONTH(tanggal)', date('m'))
                    ->where('YEAR(tanggal)', date('Y'))
                    ->first(); // Mengambil hasil pertama sebagai array
    }
}

