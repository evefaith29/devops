<?php

namespace App\Models;

use CodeIgniter\Model;

class PemasukanModel extends Model
{
    protected $table = 'pemasukan_sekolah';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'jenis_pemasukan', 'jumlah_pemasukan', 'nama'];

    public function getByJenis($jenis = null)
    {
        if ($jenis) {
            return $this->where('jenis_pemasukan', $jenis)->findAll();
        }
        return $this->findAll();
    }

    public function totalPemasukanHarian($tanggal)
    {
        if (!$this->isValidDate($tanggal)) {
            return ['jumlah_pemasukan' => 0];
        }

        return $this->selectSum('jumlah_pemasukan')
                    ->where('DATE(tanggal)', $tanggal)
                    ->first() ?? ['jumlah_pemasukan' => 0];
    }

    public function totalPemasukanPerBulan($bulan, $tahun)
    {
        return $this->selectSum('jumlah_pemasukan')
                    ->where('MONTH(tanggal)', $bulan)
                    ->where('YEAR(tanggal)', $tahun)
                    ->first() ?? ['jumlah_pemasukan' => 0];
    }

    public function totalPemasukanPerTahun($tahun)
    {
        return $this->selectSum('jumlah_pemasukan')
                    ->where('YEAR(tanggal)', $tahun)
                    ->first() ?? ['jumlah_pemasukan' => 0];
    }

    private function isValidDate($date, $format = 'Y-m-d')
    {
        $d = \DateTime::createFromFormat($format, $date);
        return $d && $d->format($format) === $date;
    }
}
