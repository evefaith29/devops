namespace App\Models;

use CodeIgniter\Model;

class KelasModel extends Model
{
    protected $table = 'kelas';       // Nama tabel di database
    protected $primaryKey = 'id';     // Kolom primary key
    protected $allowedFields = ['nama_kelas', 'tingkat']; // Kolom yang bisa diisi

    // Nonaktifkan timestamps jika tabel tidak memiliki kolom created_at dan updated_at
    protected $useTimestamps = false;
}
