<?php

namespace App\Models;

use CodeIgniter\Model;

class PenjualanPerlengkapanModel extends Model
{
    protected $table = 'penjualan_perlengkapan';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'nama', 'jenis_perlengkapan', 'jumlah'];

    public function getTotalPemasukanBulanIni()
    {
        return $this->selectSum('jumlah') // Menggunakan selectSum untuk menghitung total
                    ->where('MONTH(tanggal)', date('m'))
                    ->where('YEAR(tanggal)', date('Y'))
                    ->first(); // Mengambil hasil pertama sebagai array
    }
}
