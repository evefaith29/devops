<?php

namespace App\Models;

use CodeIgniter\Model;

class M_Siswa extends Model
{
    protected $table = 'siswa'; // Nama tabel di database
    protected $primaryKey = 'id'; // Primary key
    protected $allowedFields = ['payment', 'name']; // Field yang diizinkan untuk diisi

    public function getAllData($search = null)
    {
        if ($search) {
            return $this->like('name', $search)->findAll();
        }
        return $this->findAll();
    }

    public function getDataById($id)
    {
        return $this->where('id', $id)->first();
    }

    public function tambah($data)
    {
        return $this->insert($data);
    }

    public function edit($data, $id)
    {
        return $this->update($id, $data);
    }

    public function hapus($id)
    {
        return $this->delete($id);
    }
}
