<?php

// app/Models/AcaraSekolahModel.php

namespace App\Models;

use CodeIgniter\Model;

class AcaraSekolahModel extends Model
{
    protected $table = 'acara_sekolah';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'nama', 'jenis_acara', 'jumlah'];

    // Mendapatkan total pengeluaran bulan ini
    public function getTotalPengeluaranBulanIni()
    {
        return $this->selectSum('jumlah') // Menggunakan selectSum untuk menghitung total
                    ->where('MONTH(tanggal)', date('m'))
                    ->where('YEAR(tanggal)', date('Y'))
                    ->first(); // Mengambil hasil pertama sebagai array
    }
    public function getTotalPengeluaranSeluruhnya()
    {
        return $this->selectSum('jumlah') // Menggunakan selectSum untuk menghitung total
                    ->first(); // Mengambil hasil pertama sebagai array
    }
}
