<?php

namespace App\Models;

use CodeIgniter\Model;

class BeasiswaModel extends Model
{
    protected $table = 'beasiswa';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'nama', 'nama_siswa', 'jenis_beasiswa', 'jumlah_beasiswa'];

    public function getTotalPemasukanBulanIni()
    {
        return $this->selectSum('jumlah_beasiswa') // Menggunakan selectSum untuk menghitung total
                    ->where('MONTH(tanggal)', date('m'))
                    ->where('YEAR(tanggal)', date('Y'))
                    ->first(); // Mengambil hasil pertama sebagai array
    }
}
