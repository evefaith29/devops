<?php

namespace App\Models;

use CodeIgniter\Model;

class PelatihanGuruModel extends Model
{
    protected $table = 'pelatihan_guru';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'nama', 'jenis_pelatihan', 'jumlah', 'jumlah_pengeluaran'];

    public function getTotalPengeluaranBulanIni()
    {
        return $this->selectSum('jumlah') // Menggunakan selectSum untuk menghitung total
                    ->where('MONTH(tanggal)', date('m'))
                    ->where('YEAR(tanggal)', date('Y'))
                    ->first(); // Mengambil hasil pertama sebagai array
    }
    public function getTotalPengeluaranSeluruhnya()
    {
        return $this->selectSum('jumlah') // Menggunakan selectSum untuk menghitung total
                    ->first(); // Mengambil hasil pertama sebagai array
    }
}
