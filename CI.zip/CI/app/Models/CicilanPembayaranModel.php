<?php

namespace App\Models;

use CodeIgniter\Model;

class CicilanPembayaranModel extends Model
{
    protected $table = 'cicilan_pembayaran';
    protected $primaryKey = 'id';
    protected $allowedFields = ['id_siswa', 'jumlah_cicilan', 'tanggal_jatuh_tempo', 'status'];
}
