<?php

namespace App\Models;

use CodeIgniter\Model;

class ExpenseModel extends Model
{
    protected $table = 'pengeluaran'; // Ganti dengan nama tabel Anda
    protected $primaryKey = 'expense_id'; // Ganti dengan nama kolom ID Anda
    protected $allowedFields = [
        'category_id',
        'expense_date',
        'expense_amount',
        'description',
        'created_at',
        'update_at',
    ];
    
    protected $useTimestamps = true; // Jika Anda menggunakan timestamp
}
