<?php

namespace App\Models;

use CodeIgniter\Model;

class PenyewaanFasilitasModel extends Model
{
    protected $table = 'penyewaan_fasilitas';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'nama', 'nama_fasilitas', 'jumlah'];

    public function getTotalPemasukanBulanIni()
    {
        return $this->selectSum('jumlah') // Menggunakan selectSum untuk menghitung total
                    ->where('MONTH(tanggal)', date('m'))
                    ->where('YEAR(tanggal)', date('Y'))
                    ->first();
    }
}
