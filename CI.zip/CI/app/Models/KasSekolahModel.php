<?php

namespace App\Models;

use CodeIgniter\Model;

class KasSekolahModel extends Model
{
    protected $tablePemasukan = 'pemasukan_sekolah';
    protected $tablePengeluaran = 'pengeluaran_sekolah';

    public function getLaporanBulanan()
    {
        $saldoBerjalan = 0;
        $laporanBulanan = [];

        // Loop dari bulan Januari hingga Desember
        for ($bulan = 1; $bulan <= 12; $bulan++) {
            // Dapatkan total pemasukan untuk bulan tertentu
            $pemasukan = $this->db->table($this->tablePemasukan)
                ->selectSum('jumlah_pemasukan', 'total_pemasukan')
                ->where('MONTH(tanggal)', $bulan)
                ->get()
                ->getRow()->total_pemasukan ?? 0;

            // Dapatkan total pengeluaran untuk bulan tertentu
            $pengeluaran = $this->db->table($this->tablePengeluaran)
                ->selectSum('jumlah_pengeluaran', 'total_pengeluaran')
                ->where('MONTH(tanggal)', $bulan)
                ->get()
                ->getRow()->total_pengeluaran ?? 0;

            // Hitung saldo berjalan untuk bulan tersebut
            $saldoBerjalan += ($pemasukan - $pengeluaran);

            // Menyusun data laporan bulanan dengan memastikan 'saldo' selalu ada
            $laporanBulanan[] = [
                'bulan' => date('F', mktime(0, 0, 0, $bulan, 10)),
                'total_pemasukan' => $pemasukan,
                'total_pengeluaran' => $pengeluaran,
                'saldo' => $saldoBerjalan // Menyimpan saldo berjalan
            ];
        }

        return $laporanBulanan;
    }
}
