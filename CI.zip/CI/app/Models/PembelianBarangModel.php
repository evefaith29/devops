<?php

// app/Models/PembelianBarangModel.php

namespace App\Models;

use CodeIgniter\Model;

class PembelianBarangModel extends Model
{
    protected $table = 'pembelian_barang';
    protected $primaryKey = 'id';
    protected $allowedFields = ['tanggal', 'nama', 'nama_barang', 'jumlah_barang', 'harga_satuan', 'total_harga'];

    public function calculateTotalHarga($jumlah_barang, $harga_satuan)
    {
        return $jumlah_barang * $harga_satuan;
    }

    // Perbaikan untuk mengambil total pengeluaran bulan ini
    public function getTotalPengeluaranBulanIni()
    {
        return $this->selectSum('total_harga') // Mengganti 'jumlah_pengeluaran' dengan 'total_harga'
                    ->where('MONTH(tanggal)', date('m'))
                    ->where('YEAR(tanggal)', date('Y'))
                    ->first()['total_harga'] ?? 0; // Mengambil total harga bulan ini, default 0 jika tidak ada
    }

    public function getTotalPengeluaranSeluruhnya()
    {
        return $this->selectSum('total_harga') // Menggunakan selectSum untuk menghitung total
                    ->first(); // Mengambil hasil pertama sebagai array
    }
}
