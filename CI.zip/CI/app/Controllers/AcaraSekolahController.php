<?php

// app/Controllers/AcaraSekolahController.php

namespace App\Controllers;

use App\Models\AcaraSekolahModel;
use App\Models\PengeluaranModel;

class AcaraSekolahController extends BaseController
{
    public function index()
    {
        $model = new AcaraSekolahModel();
        $data['acara_sekolah'] = $model->findAll();
        
        // Mendapatkan total pengeluaran bulan ini
        $totalBulanIni = $model->getTotalPengeluaranBulanIni();
        $data['total_pengeluaran_bulan_ini'] = $totalBulanIni ? $totalBulanIni['jumlah'] : 0;

        // Mendapatkan total pengeluaran seluruhnya
        $totalSeluruhnya = $model->getTotalPengeluaranSeluruhnya();
        $data['total_pengeluaran_seluruhnya'] = $totalSeluruhnya ? $totalSeluruhnya['jumlah'] : 0;

        return view('acara_sekolah/index', $data);
    }

    public function create()
    {
        return view('acara_sekolah/create');
    }

    public function store()
    {
        // Instansiasi model AcaraSekolah dan Pengeluaran
        $acaraModel = new AcaraSekolahModel();
        $pengeluaranModel = new PengeluaranModel();

        // Ambil data dari form
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_acara' => $this->request->getPost('jenis_acara'),
            'jumlah' => $this->request->getPost('jumlah'),
        ];

        // Simpan data acara sekolah
        $acaraModel->save($data);

        // Ambil data yang sama untuk disimpan di tabel pengeluaran
        $pengeluaranData = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_pengeluaran' => 'Acara Sekolah: ' . $this->request->getPost('jenis_acara'), // Deskripsi pengeluaran
            'jumlah_pengeluaran' => $this->request->getPost('jumlah'),
        ];

        // Simpan data pengeluaran
        $pengeluaranModel->save($pengeluaranData);

        return redirect()->to('/acara_sekolah');
    }

    public function edit($id)
    {
        $model = new AcaraSekolahModel();
        $data['acara'] = $model->find($id);
        return view('acara_sekolah/edit', $data);
    }

    public function update($id)
    {
        $model = new AcaraSekolahModel();

        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_acara' => $this->request->getPost('jenis_acara'),
            'jumlah' => $this->request->getPost('jumlah'),
        ];

        $model->update($id, $data);
        return redirect()->to('/acara_sekolah');
    }

    public function delete($id)
    {
        $model = new AcaraSekolahModel();
        $model->delete($id);
        return redirect()->to('/acara_sekolah');
    }
}
