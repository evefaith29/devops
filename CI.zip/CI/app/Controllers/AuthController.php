<?php

namespace App\Controllers;

use App\Models\UserModel; // Pastikan Anda punya model User untuk memverifikasi login
use CodeIgniter\Controller;

class AuthController extends Controller
{
    public function login()
    {
        return view('auth/login'); // Tampilkan halaman login
    }

    public function authenticate()
    {
        $session = session();
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        $role = $this->request->getPost('role');

        $userModel = new UserModel();
        $user = $userModel->where('username', $username)->first();

        if ($user) {
            // Verifikasi password
            if (password_verify($password, $user['password']) && $user['role'] == $role) {
                // Set session
                $session->set([
                    'username' => $user['username'],
                    'role' => $user['role'],
                    'isLoggedIn' => true
                ]);
                return redirect()->to('/home'); // Arahkan ke dashboard
            } else {
                $session->setFlashdata('error', 'Username, password, atau role salah');
                return redirect()->back();
            }
        } else {
            $session->setFlashdata('error', 'Username tidak ditemukan');
            return redirect()->back();
        }
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
