<?php 

namespace App\Controllers;

use App\Models\PenggunaModel; // Pastikan model ini sesuai dengan tabel pengguna Anda

class Login extends BaseController
{
    protected $model;

    public function __construct()
    {
        // Inisialisasi model PenggunaModel
        $this->model = new PenggunaModel();
    }

    public function index()
    {
        // Memanggil tampilan login
        return view('login'); 
    }

    public function submit()
    {
        // Mengambil data dari form login
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        // Validasi username dan password
        $user = $this->model->where('username', $username)->first();

        if ($user) {
            // Jika user ditemukan, periksa password
            if (password_verify($password, $user['password'])) {
                // Jika login berhasil, simpan user_id dalam session
                session()->set([
                    'user_id' => $user['id'],
                    'username' => $user['username'], // Menyimpan username dalam session
                    'role' => $user['role'], // Jika ada kolom role, simpan juga
                    'isLoggedIn' => true // Menandakan user sudah login
                ]);
                return redirect()->to('/home'); 
            } else {
                // Jika password salah
                return redirect()->to('/login')->with('error', 'Username atau password salah...');
            }
        } else {
            // Jika username tidak ditemukan
            return redirect()->to('/login')->with('error', 'Username atau password salah...');
        }
    }

    public function logout()
    {
        // Menghancurkan session untuk logout
        session()->destroy();
        return redirect()->to('/login');
    }
}
