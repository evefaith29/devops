<?php

namespace App\Controllers;

use App\Models\PengeluaranModel;
use App\Models\PenggajianModel;
use App\Models\PembelianBarangModel;
use App\Models\PemeliharaanPerawatanModel;
use App\Models\TagihanModel;
use App\Models\AcaraSekolahModel;
use App\Models\PelatihanGuruModel;
use App\Models\TransportasiModel;
use App\Models\HutangSekolahModel;
use App\Models\PembiayaanProyekModel;
use App\Models\BeasiswaModel;

class PengeluaranController extends BaseController
{
    protected $PengeluaranModel;
    protected $PenggajianModel;
    protected $PembelianBarangModel;
    protected $PemeliharaanPerawatanModel;
    protected $TagihanModel;
    protected $AcaraSekolahModel;
    protected $PelatihanGuruModel;
    protected $TransportasiModel;
    protected $HutangSekolahModel;
    protected $PembiayaanProyekModel;
    protected $BeasiswaModel;

    public function __construct()
    {
        $this->PengeluaranModel = new PengeluaranModel();
        $this->PenggajianModel = new PenggajianModel();
        $this->PembelianBarangModel = new PembelianBarangModel();
        $this->PemeliharaanPerawatanModel = new PemeliharaanPerawatanModel();
        $this->TagihanModel = new TagihanModel();
        $this->AcaraSekolahModel = new AcaraSekolahModel();
        $this->PelatihanGuruModel = new PelatihanGuruModel();
        $this->TransportasiModel = new TransportasiModel();
        $this->HutangSekolahModel = new HutangSekolahModel();
        $this->PembiayaanProyekModel = new PembiayaanProyekModel();
        $this->BeasiswaModel = new BeasiswaModel();
    }

    public function index()
    {
        $penggajian = $this->PenggajianModel->findAll();
        foreach ($penggajian as &$item) {
            $item['jenis_pengeluaran'] = 'Penggajian';
            $item['jumlah_pengeluaran'] = $item['jumlah_gaji'];
        }

        $PembelianBarang = $this->PembelianBarangModel->findAll();
        foreach ($PembelianBarang as &$item) {
            $item['jenis_pengeluaran'] = 'Pembelian Barang';
            $item['jumlah_pengeluaran'] = $item['total_harga'];
        }

        $pemeliharaanPerawatan = $this->PemeliharaanPerawatanModel->findAll();
        foreach ($pemeliharaanPerawatan as &$item) {
            $item['jenis_pengeluaran'] = 'Donasi';
            $item['jumlah_pengeluaran'] = $item['jumlah'];
        }

        $tagihan = $this->TagihanModel->findAll();
        foreach ($tagihan as &$item) {
            $item['jenis_pengeluaran'] = 'Tagihan';
            $item['jumlah_pengeluaran'] = $item['jumlah'];
        }

        $acaraSekolah = $this->AcaraSekolahModel->findAll();
        foreach ($acaraSekolah as &$item) {
            $item['jenis_pengeluaran'] = 'Acara Sekolah';
            $item['jumlah_pengeluaran'] = $item['jumlah'];
        }

        $pelatihanGuru = $this->PelatihanGuruModel->findAll();
        foreach ($pelatihanGuru as &$item) {
            $item['jenis_pengeluaran'] = 'Pelatihan Guru';
            $item['jumlah_pengeluaran'] = $item['jumlah'];
        }

        $transportasi = $this->TransportasiModel->findAll();
        foreach ($transportasi as &$item) {
            $item['jenis_pengeluaran'] = 'transportasi';
            $item['jumlah_pengeluaran'] = $item['jumlah'];
        }
        $hutangSekolah = $this->HutangSekolahModel->findAll();
        foreach ($hutangSekolah as &$item) {
            $item['jenis_pengeluaran'] = 'Hutang Sekolah';
            $item['jumlah_pengeluaran'] = $item['dibayar'];
        }

        $pembiayaanProyek = $this->PembiayaanProyekModel->findAll();
        foreach ($pembiayaanProyek as &$item) {
            $item['jenis_pengeluaran'] = 'Pembiayaan Proyek';
            $item['jumlah_pengeluaran'] = $item['anggaran_terpakai'];
        }

        $beasiswa = $this->BeasiswaModel->findAll();
        foreach ($beasiswa as &$item) {
            $item['jenis_pengeluaran'] = 'beasiswa';
            $item['jumlah_pengeluaran'] = $item['jumlah_beasiswa'];
        }
        // Gabungkan semua data pengeluaran dalam satu array
        $allpengeluaran = array_merge($penggajian, $PembelianBarang, $pemeliharaanPerawatan, $tagihan, $acaraSekolah, $pelatihanGuru, $transportasi, $hutangSekolah, $pembiayaanProyek, $beasiswa);

        // Sorting data pengeluaran berdasarkan tanggal secara descending
        usort($allpengeluaran, function ($a, $b) {
            return strtotime($b['tanggal']) - strtotime($a['tanggal']);
        });

        // Hitung total pengeluaran
        $totalpengeluaran = array_sum(array_column($allpengeluaran, 'jumlah_pengeluaran'));

        $data['pengeluaran'] = $allpengeluaran;
        $data['totalpengeluaran'] = $totalpengeluaran;

        return view('pengeluaran/index', $data);
    }
    

    private function getTotalPengeluaranKeseluruhan()
    {
        $models = [
            ['model' => $this->PenggajianModel, 'column' => 'jumlah_gaji'],
            ['model' => $this->PembelianBarangModel, 'column' => 'total_harga'],
            ['model' => $this->PemeliharaanPerawatanModel, 'column' => 'jumlah'],
            ['model' => $this->TagihanModel, 'column' => 'jumlah'],
            ['model' => $this->AcaraSekolahModel, 'column' => 'jumlah'],
            ['model' => $this->PelatihanGuruModel, 'column' => 'jumlah'],
            ['model' => $this->TransportasiModel, 'column' => 'jumlah'],
            ['model' => $this->HutangSekolahModel, 'column' => 'dibayar'],
            ['model' => $this->PembiayaanProyekModel, 'column' => 'anggaran_terpakai'],
            ['model' => $this->BeasiswaModel, 'column' => 'jumlah_beasiswa'],
        ];
    
        $totalPengeluaranKeseluruhan = 0;
    
        foreach ($models as $entry) {
            $model = $entry['model'];
            $column = $entry['column'];
            $result = $model->selectSum($column)->first();
            $totalPengeluaranKeseluruhan += $result[$column] ?? 0;
        }
    
        return $totalPengeluaranKeseluruhan;
    }

    public function storeAll() {
        $dataPengeluaran = $this->request->getJSON(true);
        log_message('info', 'Data yang diterima: ' . json_encode($dataPengeluaran));
        
        if (!$dataPengeluaran) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Data tidak diterima']);
        }
    
        $errors = []; // Menyimpan error jika ada
    
        foreach ($dataPengeluaran as $item) {
            // Pastikan format tanggal benar
            if (!empty($item['tanggal']) && !empty($item['jenis_pengeluaran']) && isset($item['jumlah_pengeluaran'])) {
                // Menyimpan data ke database
                if (!$this->PengeluaranModel->insert([
                    'tanggal' => $item['tanggal'],
                    'jenis_pengeluaran' => $item['jenis_pengeluaran'],
                    'jumlah_pengeluaran' => $item['jumlah_pengeluaran'],
                    'nama' => $item['nama']
                ])) {
                    $errors[] = 'Gagal menyimpan data untuk: ' . json_encode($item);
                    log_message('error', 'Gagal menyimpan data: ' . json_encode($item));
                }
            } else {
                $errors[] = 'Data tidak lengkap: ' . json_encode($item);
                log_message('error', 'Data tidak lengkap: ' . json_encode($item));
            }
        }
    
        // Menyusun respons akhir
        if (count($errors) > 0) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Beberapa data gagal disimpan', 'errors' => $errors]);
        }
    
        return $this->response->setJSON(['status' => 'success', 'message' => 'Data berhasil disimpan']);
    }
    
    
    
    
    
    
    

    public function create()
    {
        return view('pengeluaran/create'); // View ini menampilkan form input pengeluaran
    }
    
    public function store()
    {
        // Ambil semua input dari form
        $tanggal = $this->request->getPost('tanggal');
        $jenis_pengeluaran = $this->request->getPost('jenis_pengeluaran');
        $jumlah_pengeluaran = $this->request->getPost('jumlah_pengeluaran');
        $nama = $this->request->getPost('nama');
    
        // Inisialisasi array data yang akan disimpan
        $dataPengeluaran = [];
        for ($i = 0; $i < count($tanggal); $i++) {
            $dataPengeluaran[] = [
                'tanggal' => $tanggal[$i],
                'jenis_pengeluaran' => $jenis_pengeluaran[$i],
                'jumlah_pengeluaran' => $jumlah_pengeluaran[$i],
                'nama' => $nama[$i]
            ];
        }
    
        // Simpan data ke database
        $pengeluaranModel = new PengeluaranModel();
        $pengeluaranModel->insertBatch($dataPengeluaran);
    
        // Redirect kembali ke halaman laporan pengeluaran
        return redirect()->to('/pengeluaran');
    }
    
    
    
    

    public function update($id)
    {
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'jenis_pengeluaran' => $this->request->getPost('jenis_pengeluaran'),
            'jumlah_pengeluaran' => $this->request->getPost('jumlah_pengeluaran'),
            'nama' => $this->request->getPost('nama')
        ];

        $this->PengeluaranModel->update($id, $data);
        return redirect()->to('/pengeluaran')->with('success', 'Data pengeluaran berhasil diupdate!');
    }


    public function delete($id)
{
    $pengeluaranModel = new \App\Models\PengeluaranModel();

    if ($pengeluaranModel->delete($id)) {
        return $this->response->setJSON(['message' => 'Data berhasil dihapus']);
    } else {
        return $this->response->setJSON(['message' => 'Gagal menghapus data'], 500);
    }
}


}
