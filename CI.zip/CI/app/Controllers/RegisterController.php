<?php

namespace App\Controllers;

use App\Models\UserModel;

class RegisterController extends BaseController
{
    // Tampilkan form pendaftaran
    public function register()
    {
        return view('register');
    }

    // Proses pendaftaran
    public function submit()
    {
        // Ambil data dari form pendaftaran
        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');
        $role = $this->request->getPost('role'); // Ambil role dari form

        $userModel = new UserModel();

        // Cek apakah username sudah ada di database
        if ($userModel->where('username', $username)->first()) {
            return redirect()->back()->with('error', 'Username sudah terdaftar. Silakan gunakan username lain.');
        }

        // Hash password sebelum disimpan ke database
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // Simpan ke database
        $data = [
            'username' => $username,
            'password' => $hashedPassword,  // Simpan password yang sudah di-hash
            'role' => $role // Simpan role yang dipilih
        ];

        $userModel->insert($data);

        return redirect()->to('admin/list_account')->with('success', 'Pendaftaran berhasil! Silakan login.');
    }

    // Edit akun pengguna
    public function edit($id)
    {
        $userModel = new UserModel();

        // Ambil data user berdasarkan ID
        $user = $userModel->find($id);

        // Cek apakah user ditemukan
        if (!$user) {
            return redirect()->to('admin/list_account')->with('error', 'User tidak ditemukan');
        }

        // Jika form disubmit
        if ($this->request->getMethod() === 'post') {
            // Ambil data dari form
            $username = $this->request->getPost('username');
            $password = $this->request->getPost('password');
            $role = $this->request->getPost('role');

            // Jika password diubah, lakukan hashing password
            if (!empty($password)) {
                $password = password_hash($password, PASSWORD_DEFAULT);
            } else {
                $password = $user['password']; // Gunakan password lama jika tidak diubah
            }

            // Simpan perubahan ke database
            $data = [
                'username' => $username,
                'password' => $password,
                'role' => $role
            ];

            // Update data user
            $userModel->update($id, $data);

            return redirect()->to('admin/list_account')->with('success', 'Akun berhasil diperbarui');
        }

        // Tampilkan form edit akun
        return view('admin/edit_account', ['user' => $user]);
    }

    // Hapus akun pengguna
    public function delete($id)
    {
        $userModel = new UserModel();

        // Cek apakah user ada di database
        $user = $userModel->find($id);

        // Jika user tidak ditemukan
        if (!$user) {
            return redirect()->to('admin/list_account')->with('error', 'User tidak ditemukan');
        }

        // Hapus data user dari database
        $userModel->delete($id);

        return redirect()->to('admin/list_account')->with('success', 'Akun berhasil dihapus');
    }

    // Menampilkan daftar akun
    public function listAccount()
    {
        $userModel = new UserModel();
        $users = $userModel->findAll();  // Menampilkan semua akun
        return view('admin/list_account', ['users' => $users]);
    }
}
