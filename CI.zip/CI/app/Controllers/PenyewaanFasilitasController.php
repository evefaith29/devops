<?php

namespace App\Controllers;

use App\Models\PenyewaanFasilitasModel;
use App\Models\PemasukanModel;
use CodeIgniter\Controller;

class PenyewaanFasilitasController extends Controller
{
    public function index()
    {
        $model = new PenyewaanFasilitasModel();
        $data['penyewaan'] = $model->findAll();
        $data['spps'] = $model->findAll();
        $total = $model->getTotalPemasukanBulanIni();
        $data['total_pemasukan'] = $total ? $total['jumlah'] : 0;
        return view('penyewaan_fasilitas/index', $data);
    }

    public function create()
    {
        return view('penyewaan_fasilitas/create');
    }

    public function store()
    {
        $penyewaanModel = new PenyewaanFasilitasModel();
        $pemasukanModel = new PemasukanModel(); // Tambahkan model untuk pemasukan sekolah
    
        $jumlah = $this->request->getPost('jumlah');
    
        // Data untuk tabel penyewaan_fasilitas
        $dataPenyewaan = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_fasilitas' => $this->request->getPost('nama_fasilitas'),
            'jumlah' => $jumlah,
        ];
    
        // Simpan ke tabel penyewaan_fasilitas
        $penyewaanModel->insert($dataPenyewaan);
    
        // Data untuk tabel pemasukan_sekolah
        $dataPemasukan = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_pemasukan' => 'Penyewaan Fasilitas', // Sesuaikan dengan kebutuhan
            'jumlah_pemasukan' => $jumlah,
        ];
    
        // Simpan ke tabel pemasukan_sekolah
        $pemasukanModel->insert($dataPemasukan);
    
        return redirect()->to('/penyewaan_fasilitas');
    }
    

    public function edit($id)
    {
        $model = new PenyewaanFasilitasModel();
        $data['penyewaan'] = $model->find($id);
        return view('penyewaan_fasilitas/edit', $data);
    }

    public function update($id)
    {
        $model = new PenyewaanFasilitasModel();
        $jumlah = $this->request->getPost('jumlah');

        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_fasilitas' => $this->request->getPost('nama_fasilitas'),
            'jumlah' => $jumlah,
        ];

        $model->update($id, $data);
        return redirect()->to('/penyewaan_fasilitas');
    }

    public function delete($id)
    {
        $model = new PenyewaanFasilitasModel();
        $model->delete($id);
        return redirect()->to('/penyewaan_fasilitas');
    }
}
