<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\M_Siswa;

class Siswa extends Controller
{
    protected $model;

    public function __construct()
    {
        $this->model = new M_Siswa();
    }

    public function index()
    {
        $search = $this->request->getVar('search'); // Ambil dari query string jika ada
        $data = [
            'judul' => 'Data Siswa',
            'siswa' => $this->model->getAllData($search), // Pastikan model mendukung pencarian
            'search' => $search // Kirim variabel search ke view
        ];
        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar');
        echo view('templates/v_topbar');
        echo view('siswa/index', $data);
        echo view('templates/v_footer');
    }

    public function tambah()
    {
        if ($this->request->getMethod() === 'post') {
            // Validasi input
            $validation = $this->validate([
                'payment' => [
                    'label' => 'Pembayaran',
                    'rules' => 'required'
                ],
                'name' => [
                    'label' => 'Nama Siswa',
                    'rules' => 'required'
                ]
            ]);

            if (!$validation) {
                // Jika validasi gagal, tampilkan error dan kembali ke halaman
                session()->setFlashdata('err', \Config\Services::validation()->listErrors());

                return redirect()->to('/siswa')->withInput(); // Kembali dengan input sebelumnya
            } else {
                // Jika validasi berhasil, simpan data
                $data = [
                    'payment' => $this->request->getPost('payment'),
                    'name' => $this->request->getPost('name')
                ];

                $success = $this->model->tambah($data);
                if ($success) {
                    session()->setFlashdata('message', 'Data berhasil ditambahkan');
                    return redirect()->to('/siswa');
                }
            }
        }

        return redirect()->to('/siswa');
    }

    public function hapus($id)
    {
        // Menghapus data siswa
        $success = $this->model->hapus($id);

        if ($success) {
            session()->setFlashdata('message', 'Data berhasil dihapus');
        } else {
            session()->setFlashdata('message', 'Gagal menghapus data');
        }

        return redirect()->to('/siswa');
    }

    public function edit($id)
    {
        // Ambil data siswa untuk ditampilkan di form edit
        $data['judul'] = 'Edit Siswa';
        $data['siswa'] = $this->model->getDataById($id);
    
        if (!$data['siswa']) {
            session()->setFlashdata('message', 'Data siswa tidak ditemukan.');
            return redirect()->to('/siswa');
        }
    
        if ($this->request->getMethod() === 'post') {
            // Validasi input
            $validation = $this->validate([
                'payment' => [
                    'label' => 'Pembayaran',
                    'rules' => 'required'
                ],
                'name' => [
                    'label' => 'Nama Siswa',
                    'rules' => 'required'
                ]
            ]);
    
            if (!$validation) {
                session()->setFlashdata('err', \Config\Services::validation()->listErrors());
                return redirect()->back()->withInput();
            } else {
                $dataUpdate = [
                    'payment' => $this->request->getPost('payment'),
                    'name' => $this->request->getPost('name')
                ];
    
                $success = $this->model->ubah($dataUpdate, $id);
                if ($success) {
                    session()->setFlashdata('message', 'Data berhasil diubah');
                    return redirect()->to('/siswa');
                }
            }
        }
    
        // Menampilkan form edit jika bukan POST atau setelah validasi gagal
        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar', $data);
        echo view('templates/v_topbar', $data);
        echo view('siswa/edit', $data);
        echo view('templates/v_footer', $data);
    
        // Debug output
        echo "<script>console.log('Reached edit method');</script>";
    }
}    