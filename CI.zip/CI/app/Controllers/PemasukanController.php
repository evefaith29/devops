<?php

namespace App\Controllers;

use App\Models\PemasukanModel;
use App\Models\SppModel;
use App\Models\PendaftaranModel;
use App\Models\DonasiModel;
use App\Models\PenyewaanFasilitasModel;
use App\Models\PenjualanPerlengkapanModel;
use App\Models\DanaYayasanModel;

class PemasukanController extends BaseController
{
    protected $pemasukanModel;
    protected $sppModel;
    protected $pendaftaranModel;
    protected $donasiModel;
    protected $penyewaanFasilitasModel;
    protected $penjualanPerlengkapanModel;
    protected $danaYayasanModel;

    public function __construct()
    {
        $this->pemasukanModel = new PemasukanModel();
        $this->sppModel = new SppModel();
        $this->pendaftaranModel = new PendaftaranModel();
        $this->donasiModel = new DonasiModel();
        $this->penyewaanFasilitasModel = new PenyewaanFasilitasModel();
        $this->penjualanPerlengkapanModel = new PenjualanPerlengkapanModel();
        $this->danaYayasanModel = new DanaYayasanModel();
    }

    public function index()
    {
        // Ambil dan format semua data pemasukan dari masing-masing model
        $spp = $this->sppModel->findAll();
        foreach ($spp as &$item) {
            $item['jenis_pemasukan'] = 'SPP';
            $item['jumlah_pemasukan'] = $item['jumlah_dibayar'];
        }

        $pendaftaran = $this->pendaftaranModel->findAll();
        foreach ($pendaftaran as &$item) {
            $item['jenis_pemasukan'] = 'Pendaftaran';
            $item['jumlah_pemasukan'] = $item['jumlah_yang_dibayar'];
        }

        $donasi = $this->donasiModel->findAll();
        foreach ($donasi as &$item) {
            $item['jenis_pemasukan'] = 'Donasi';
            $item['jumlah_pemasukan'] = $item['jumlah_donasi'];
        }

        $penyewaanFasilitas = $this->penyewaanFasilitasModel->findAll();
        foreach ($penyewaanFasilitas as &$item) {
            $item['jenis_pemasukan'] = 'Penyewaan Fasilitas';
            $item['jumlah_pemasukan'] = $item['jumlah'];
        }

        $penjualanPerlengkapan = $this->penjualanPerlengkapanModel->findAll();
        foreach ($penjualanPerlengkapan as &$item) {
            $item['jenis_pemasukan'] = 'Penjualan Perlengkapan';
            $item['jumlah_pemasukan'] = $item['jumlah'];
        }

        $danaYayasan = $this->danaYayasanModel->findAll();
        foreach ($danaYayasan as &$item) {
            $item['jenis_pemasukan'] = 'Dana Yayasan';
            $item['jumlah_pemasukan'] = $item['jumlah'];
        }

        // Gabungkan semua data pemasukan dalam satu array
        $allPemasukan = array_merge($spp, $pendaftaran, $donasi, $penyewaanFasilitas, $penjualanPerlengkapan, $danaYayasan);

        // Sorting data pemasukan berdasarkan tanggal secara descending
        usort($allPemasukan, function ($a, $b) {
            return strtotime($b['tanggal']) - strtotime($a['tanggal']);
        });

        // Hitung total pemasukan
        $totalPemasukan = array_sum(array_column($allPemasukan, 'jumlah_pemasukan'));

        $data['pemasukan'] = $allPemasukan;
        $data['totalPemasukan'] = $totalPemasukan;

        return view('pemasukan/index', $data);
    }

    private function getTotalPemasukanKeseluruhan()
{
    $models = [
        ['model' => $this->sppModel, 'column' => 'jumlah_dibayar'],
        ['model' => $this->pendaftaranModel, 'column' => 'jumlah_yang_dibayar'],
        ['model' => $this->donasiModel, 'column' => 'jumlah_donasi'],
        ['model' => $this->penyewaanFasilitasModel, 'column' => 'jumlah'],
        ['model' => $this->penjualanPerlengkapanModel, 'column' => 'jumlah'],
        ['model' => $this->danaYayasanModel, 'column' => 'jumlah'],
    ];

    $totalPemasukanKeseluruhan = 0;

    foreach ($models as $entry) {
        $model = $entry['model'];
        $column = $entry['column'];
        $result = $model->selectSum($column)->first();
        $totalPemasukanKeseluruhan += $result[$column] ?? 0;
    }

    return $totalPemasukanKeseluruhan;
}


    public function create()
    {
        return view('pemasukan/create');
    }

    public function store()
    {
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'jenis_pemasukan' => $this->request->getPost('jenis_pemasukan'),
            'jumlah_pemasukan' => $this->request->getPost('jumlah_pemasukan'),
            'nama' => $this->request->getPost('nama')
        ];

        $this->pemasukanModel->save($data);
        return redirect()->to('/pemasukan')->with('success', 'Data pemasukan berhasil disimpan!');
    }

    public function edit($id)
    {
        $data['pemasukan'] = $this->pemasukanModel->find($id);
        return view('pemasukan/edit', $data);
    }

    public function update($id)
    {
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'jenis_pemasukan' => $this->request->getPost('jenis_pemasukan'),
            'jumlah_pemasukan' => $this->request->getPost('jumlah_pemasukan'),
            'nama' => $this->request->getPost('nama')
        ];

        $this->pemasukanModel->update($id, $data);
        return redirect()->to('/pemasukan')->with('success', 'Data pemasukan berhasil diupdate!');
    }

    public function delete($id)
    {
        $this->pemasukanModel->delete($id);
        return redirect()->to('/pemasukan')->with('success', 'Data pemasukan berhasil dihapus!');
    }



    public function spp()
    {
        $data['spp'] = $this->sppModel->findAll();
        return view('pemasukan/spp', $data);
    }

    public function storeSpp()
    {
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_siswa' => $this->request->getPost('nama_siswa'),
            'jumlah_yang_harus_dibayar' => $this->request->getPost('jumlah_yang_harus_dibayar'),
            'jumlah_dibayar' => $this->request->getPost('jumlah_dibayar')
        ];

        $this->sppModel->save($data);
        return redirect()->to('/pemasukan/spp')->with('success', 'Data SPP berhasil disimpan!');
    }

    public function pendaftaran()
    {
        $data['pendaftaran'] = $this->pendaftaranModel->findAll();
        return view('pemasukan/pendaftaran', $data);
    }

    public function storePendaftaran()
    {
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_siswa' => $this->request->getPost('nama_siswa'),
            'jumlah_yang_harus_dibayar' => $this->request->getPost('jumlah_yang_harus_dibayar'),
            'jumlah_yang_dibayar' => $this->request->getPost('jumlah_yang_dibayar')
        ];

        $this->pendaftaranModel->save($data);
        return redirect()->to('/pemasukan/pendaftaran')->with('success', 'Data Pendaftaran berhasil disimpan!');
    }

    public function donasi()
    {
        $data['donasi'] = $this->donasiModel->findAll();
        return view('pemasukan/donasi', $data);
    }

    public function storeDonasi()
    {
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'asal_donasi' => $this->request->getPost('asal_donasi'),
            'jumlah_donasi' => $this->request->getPost('jumlah_donasi')
        ];

        $this->donasiModel->save($data);
        return redirect()->to('/pemasukan/donasi')->with('success', 'Data Donasi berhasil disimpan!');
    }

    public function penyewaan()
    {
        $data['penyewaan'] = $this->penyewaanFasilitasModel->findAll();
        return view('pemasukan/penyewaan_fasilitas', $data);
    }

    public function storePenyewaan()
    {
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_fasilitas' => $this->request->getPost('nama_fasilitas'),
            'jumlah' => $this->request->getPost('jumlah')
        ];

        $this->penyewaanFasilitasModel->save($data);
        return redirect()->to('/pemasukan/penyewaan_fasilitas')->with('success', 'Data Penyewaan berhasil disimpan!');
    }

    public function penjualan()
    {
        $data['penjualan'] = $this->penjualanPerlengkapanModel->findAll();
        return view('pemasukan/penjualan_perlengkapan', $data);
    }

    public function storePenjualan()
    {
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_perlengkapan' => $this->request->getPost('jenis_perlengkapan'),
            'jumlah' => $this->request->getPost('jumlah')
        ];

        $this->penjualanPerlengkapanModel->save($data);
        return redirect()->to('/pemasukan/penjualan_perlengkapan')->with('success', 'Data Penjualan berhasil disimpan!');
    }

    public function danaYayasan()
    {
        $data['dana_yayasan'] = $this->danaYayasanModel->findAll();
        return view('pemasukan/dana_yayasan', $data);
    }

    public function storeDanaYayasan()
    {
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jumlah' => $this->request->getPost('jumlah')
        ];

        $this->danaYayasanModel->save($data);
        return redirect()->to('/pemasukan/dana_yayasan')->with('success', 'Data Dana Yayasan berhasil disimpan!');
    }
}
