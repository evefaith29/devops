<?php

namespace App\Controllers;

use App\Models\SPPModel;
use App\Models\PemasukanModel;
use CodeIgniter\Controller;

class SPPController extends Controller
{
    public function index()
    {
        $model = new SPPModel();
        $data['spps'] = $model->findAll();
        $total = $model->getTotalPemasukanBulanIni();
        $data['total_pemasukan'] = $total ? $total['jumlah_dibayar'] : 0;
        return view('spp/index', $data);
    }

    public function create()
    {
        $data['jumlah_default'] = $this->getJumlahSPP(); // Ambil jumlah terbaru
        return view('spp/create', $data);
    }
    

    public function store()
    {
        $sppModel = new SPPModel();
        $pemasukanModel = new PemasukanModel(); // Menambahkan model Pemasukan

        // Mendapatkan data dari form
        $tanggal = $this->request->getPost('tanggal');
        $nama = $this->request->getPost('nama');
        $namaSiswa = $this->request->getPost('nama_siswa');
        $jumlahYangHarusDibayar = $this->request->getPost('jumlah_yang_harus_dibayar') ?? 500000; // Default jika tidak ada input
        $jumlahDibayar = $this->request->getPost('jumlah_dibayar');

        // Menyimpan data ke tabel SPP
        $dataSPP = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'nama_siswa' => $namaSiswa,
            'jumlah_yang_harus_dibayar' => $jumlahYangHarusDibayar,
            'jumlah_dibayar' => $jumlahDibayar
        ];
        
        $sppModel->insert($dataSPP);

        // Menyimpan data ke tabel pemasukan_sekolah
        $dataPemasukan = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'jenis_pemasukan' => 'SPP',  // Jenis pemasukan SPP
            'jumlah_pemasukan' => $jumlahDibayar // Jumlah yang dibayar untuk SPP
        ];

        $pemasukanModel->save($dataPemasukan);

        // Redirect setelah menyimpan
        return redirect()->to('/spp');
    }


    public function getJumlahSPP()
    {
        $db = \Config\Database::connect();
        $query = $db->query("SELECT jumlah_spp FROM pengaturan_spp ORDER BY berlaku_mulai DESC LIMIT 1");
        $result = $query->getRow();
        return $result ? $result->jumlah_spp : 500000; // Default jika tidak ada data
    }

    

    public function edit($id)
    {
        $model = new SPPModel();
        $data['spp'] = $model->find($id);

        return view('spp/edit', $data);
    }

    public function update($id)
    {
        $model = new SPPModel();
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_siswa' => $this->request->getPost('nama_siswa'),
            'jumlah_yang_harus_dibayar' => $this->request->getPost('jumlah_yang_harus_dibayar'),
            'jumlah_dibayar' => $this->request->getPost('jumlah_dibayar')
        ];

        $model->update($id, $data);
        return redirect()->to('/spp');
    }

    public function delete($id)
    {
        $model = new SPPModel();
        $model->delete($id);
        return redirect()->to('/spp');
    }
}
