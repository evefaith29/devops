<?php

namespace App\Controllers;

use App\Models\RoleModel;

class RoleController extends BaseController
{
    protected $roleModel;

    public function __construct()
    {
        $this->roleModel = new RoleModel();
    }

    public function index()
    {
        // Mengambil semua peran dari model
        $data['roles'] = $this->roleModel->findAll();
        $data['judul'] = "Daftar Peran"; // Menambahkan judul untuk tampilan index
        return view('roles/index', $data);
    }

    public function create()
    {
        $data['judul'] = "Buat Peran Baru"; // Menambahkan judul untuk tampilan create
        return view('roles/create', $data);
    }

    public function store()
    {
        // Menyimpan data peran baru
        $roleName = $this->request->getPost('role_name');

        // Validasi input
        if (empty($roleName)) {
            // Menyimpan pesan error
            session()->setFlashdata('error', 'Nama peran tidak boleh kosong.');
            return redirect()->back()->withInput(); // Kembali ke halaman sebelumnya dengan input
        }

        $this->roleModel->save([
            'role_name' => $roleName,
        ]);

        // Menyimpan pesan sukses
        session()->setFlashdata('success', 'Peran berhasil dibuat.');
        return redirect()->to('/roles');
    }

    public function edit($id)
    {
        $data['role'] = $this->roleModel->find($id);
        if (!$data['role']) {
            // Menangani jika role tidak ditemukan
            session()->setFlashdata('error', 'Peran tidak ditemukan.');
            return redirect()->to('/roles');
        }

        $data['judul'] = "Edit Peran"; // Menambahkan judul untuk tampilan edit
        return view('roles/edit', $data);
    }

    public function update($id)
    {
        // Validasi dan update peran
        $roleName = $this->request->getPost('role_name');

        if (empty($roleName)) {
            // Menyimpan pesan error
            session()->setFlashdata('error', 'Nama peran tidak boleh kosong.');
            return redirect()->back()->withInput(); // Kembali ke halaman sebelumnya dengan input
        }

        $this->roleModel->update($id, [
            'role_name' => $roleName,
        ]);

        // Menyimpan pesan sukses
        session()->setFlashdata('success', 'Peran berhasil diperbarui.');
        return redirect()->to('/roles');
    }

    public function delete($id)
    {
        if ($this->roleModel->delete($id)) {
            // Menyimpan pesan sukses
            session()->setFlashdata('success', 'Peran berhasil dihapus.');
        } else {
            // Menyimpan pesan error jika gagal
            session()->setFlashdata('error', 'Gagal menghapus peran.');
        }
        return redirect()->to('/roles');
    }
}
