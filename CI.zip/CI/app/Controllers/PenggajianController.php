<?php

namespace App\Controllers;

use App\Models\PenggajianModel;
use App\Models\PengeluaranModel;
use CodeIgniter\Controller;

class PenggajianController extends Controller
{
    protected $penggajianModel;

    public function __construct()
    {
        $this->penggajianModel = new PenggajianModel();
    }

    public function index()
    {
        $data['penggajian'] = $this->penggajianModel->findAll();
        
        // Total pengeluaran bulan ini
        $totalBulanIni = $this->penggajianModel->getTotalPengeluaranBulanIni();
        $data['total_pengeluaran_bulan_ini'] = $totalBulanIni ? $totalBulanIni['jumlah_gaji'] : 0; 

        // Total pengeluaran seluruhnya
        $totalSeluruhnya = $this->penggajianModel->getTotalPengeluaranSeluruhnya();
        $data['total_pengeluaran_seluruhnya'] = $totalSeluruhnya ? $totalSeluruhnya['jumlah_gaji'] : 0;

        return view('penggajian/index', $data);
    }

    

    public function create()
    {
        return view('penggajian/create');
    }

    public function store()
    {
        $validation = \Config\Services::validation();
        $validation->setRules($this->validationRules());
    
        if (!$this->validate($validation->getRules())) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }
    
        // Data untuk disimpan ke tabel penggajian
        $dataPenggajian = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_penerima' => $this->request->getPost('nama_penerima'),
            'jabatan' => $this->request->getPost('jabatan'),
            'jumlah_gaji' => $this->request->getPost('jumlah_gaji'),
        ];
    
        // Simpan data ke tabel penggajian
        $this->penggajianModel->insert($dataPenggajian);
    
        // Data untuk disimpan ke tabel pengeluaran_sekolah
        $dataPengeluaran = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_pengeluaran' => 'Gaji: ' . $this->request->getPost('nama_penerima'), // Jenis pengeluaran diambil dari nama atau jabatan
            'jumlah_pengeluaran' => $this->request->getPost('jumlah_gaji'),
        ];
    
        // Simpan data ke tabel pengeluaran_sekolah
        $pengeluaranModel = new \App\Models\PengeluaranModel();
        $pengeluaranModel->insert($dataPengeluaran);
    
        return redirect()->to('/penggajian')->with('success', 'Data penggajian berhasil disimpan, termasuk di pengeluaran sekolah!');
    }
    

    public function edit($id)
    {
        $data['penggajian'] = $this->penggajianModel->find($id);
        return view('penggajian/edit', $data);
    }

    public function update($id)
    {
        $validation = \Config\Services::validation();
        $validation->setRules($this->validationRules());

        if (!$this->validate($validation->getRules())) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_penerima' => $this->request->getPost('nama_penerima'),
            'jabatan' => $this->request->getPost('jabatan'),
            'jumlah_gaji' => $this->request->getPost('jumlah_gaji'),
        ];

        $this->penggajianModel->update($id, $data);
        return redirect()->to('/penggajian')->with('success', 'Data penggajian berhasil diupdate!');
    }

    public function delete($id)
    {
        $this->penggajianModel->delete($id);
        return redirect()->to('/penggajian')->with('success', 'Data penggajian berhasil dihapus!');
    }

    public function storeToPengeluaran()
    {
        // Ambil semua data penggajian
        $penggajianData = $this->penggajianModel->findAll();

        // Buat instance model untuk pengeluaran sekolah
        $pengeluaranModel = new \App\Models\PengeluaranModel();

        foreach ($penggajianData as $penggajian) {
            // Data yang akan disimpan di tabel pengeluaran sekolah
            $dataPengeluaran = [
                'tanggal' => $penggajian['tanggal'],
                'nama' => $penggajian['nama'],
                'nama_penerima' => $penggajian['nama_penerima'],
                'jabatan' => $penggajian['jabatan'],
                'jumlah' => $penggajian['jumlah_gaji'], // Asumsi kolom jumlah sesuai dengan pengeluaran
                'keterangan' => 'Dari penggajian' // Bisa diubah atau dihapus sesuai kebutuhan
            ];

            // Simpan data ke tabel pengeluaran sekolah
            $pengeluaranModel->insert($dataPengeluaran);
        }

        // Redirect kembali ke halaman daftar penggajian dengan pesan sukses
        return redirect()->to('/penggajian')->with('success', 'Data penggajian berhasil disimpan ke pengeluaran sekolah!');
    }

    private function validationRules()
    {
        return [
            'tanggal' => 'required',
            'nama' => 'required',
            'nama_penerima' => 'required',
            'jabatan' => 'required',
            'jumlah_gaji' => 'required|numeric',
        ];
    }
}
