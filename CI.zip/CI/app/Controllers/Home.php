<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $role = session()->get('role'); // Ambil role dari session

        if (!$role) {
            // Jika role tidak ada, arahkan pengguna ke login
            return redirect()->to('/login');
        }

        $data = [
            'judul' => 'Homepage',
            'role' => $role, // Kirim role ke view
        ];

        echo view('templates/v_header', $data);
        echo view('templates/v_sidebar', $data);
        echo view('templates/v_topbar', $data);
        echo view('home/index', $data);
        echo view('templates/v_footer');
    }
}
