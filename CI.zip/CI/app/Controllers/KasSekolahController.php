<?php

namespace App\Controllers;

use App\Models\KasSekolahModel;

class KasSekolahController extends BaseController
{
    protected $kasSekolahModel;

    public function __construct()
    {
        $this->kasSekolahModel = new KasSekolahModel();
    }

    public function index()
    {
        // Ambil data pemasukan dan pengeluaran per bulan
        $dataLaporan = $this->kasSekolahModel->getLaporanBulanan();
        
        // Hitung total kas sekolah
        $totalKasSekolah = array_reduce($dataLaporan, function($total, $item) {
            return $total + $item['saldo'];
        }, 0);

        $data = [
            'dataLaporan' => $dataLaporan,
            'totalKasSekolah' => $totalKasSekolah
        ];

        return view('laporan_keuangan', $data);
    }
}
