<?php

namespace App\Controllers;

use App\Models\BeasiswaModel;
use App\Models\PengeluaranModel;
use CodeIgniter\Controller;

class BeasiswaController extends Controller
{
    public function index()
    {
        $model = new BeasiswaModel();
        $data['beasiswa'] = $model->findAll();
        $total = $model->getTotalPemasukanBulanIni();
        $data['total_pemasukan'] = $total ? $total['jumlah_beasiswa'] : 0;
        return view('beasiswa/index', $data);
    }

    public function create()
    {
        return view('beasiswa/create');
    }

    public function store()
    {
        $beasiswaModel = new BeasiswaModel();
        $pengeluaranModel = new PengeluaranModel(); // Menambahkan model pengeluaran 

        // Mendapatkan data dari form
        $jumlah_beasiswa = $this->request->getPost('jumlah_beasiswa');
        $tanggal = $this->request->getPost('tanggal');
        $nama = $this->request->getPost('nama');
        $nama_siswa = $this->request->getPost('nama_siswa');
        $jenis_beasiswa = $this->request->getPost('jenis_beasiswa');

        // Data untuk disimpan ke tabel beasiswa
        $dataBeasiswa = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'nama_siswa' => $nama_siswa,
            'jenis_beasiswa' => $jenis_beasiswa,
            'jumlah_beasiswa' => $jumlah_beasiswa,
            'jumlah_pengeluaran' => $jumlah_beasiswa, // otomatis terisi
        ];

        // Simpan data beasiswa ke tabel beasiswa
        $beasiswaModel->insert($dataBeasiswa);

        // Data untuk disimpan ke tabel pengeluaran_sekolah
        $dataPengeluaranSekolah = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'jenis_pengeluaran' => 'Beasiswa', // Jenis pengeluaran sesuai
            'jumlah_pengeluaran' => $jumlah_beasiswa,
        ];

        // Simpan data pengeluaran ke tabel pengeluaran_sekolah
        $pengeluaranModel->insert($dataPengeluaranSekolah);

        return redirect()->to('/beasiswa');
    }

    public function edit($id)
    {
        $model = new BeasiswaModel();
        $data['beasiswa'] = $model->find($id);
        return view('beasiswa/edit', $data);
    }

    public function update($id)
    {
        $model = new BeasiswaModel();
        $jumlah_beasiswa = $this->request->getPost('jumlah_beasiswa');

        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_siswa' => $this->request->getPost('nama_siswa'),
            'jenis_beasiswa' => $this->request->getPost('jenis_beasiswa'),
            'jumlah_beasiswa' => $jumlah_beasiswa,
            'jumlah_pengeluaran' => $jumlah_beasiswa // otomatis terisi
        ];

        $model->update($id, $data);
        return redirect()->to('/beasiswa');
    }

    public function delete($id)
    {
        $model = new BeasiswaModel();
        $model->delete($id);
        return redirect()->to('/beasiswa');
    }
}
