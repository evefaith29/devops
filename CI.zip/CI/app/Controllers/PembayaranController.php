<?php

namespace App\Controllers;

use App\Models\PembayaranModel; // Pastikan model ini sudah ada

class PembayaranController extends BaseController
{
    protected $pembayaranModel;

    public function __construct()
    {
        // Inisialisasi model pembayaran
        $this->pembayaranModel = new PembayaranModel();
    }

    // Menampilkan histori pembayaran
    public function histori()
    {
        // Ambil data histori pembayaran dari model
        $data['histori_pembayaran'] = $this->pembayaranModel->getAllHistori();

        // Tampilkan view dengan data histori pembayaran
        return view('pembayaran/index', $data);
    }

    // Menampilkan form untuk menambah pembayaran
    public function tambah()
    {
        return view('pembayaran/tambah');
    }

    // Menyimpan data pembayaran
    public function simpan()
    {
        $data = [
            'id_siswa' => $this->request->getPost('id_siswa'),
            'jumlah_pembayaran' => $this->request->getPost('jumlah_pembayaran'),
            'metode_pembayaran' => $this->request->getPost('metode_pembayaran'),
            'tanggal_pembayaran' => $this->request->getPost('tanggal_pembayaran'),
        ];

        // Simpan data ke database
        $this->pembayaranModel->insert($data);

        // Redirect ke histori pembayaran setelah berhasil
        return redirect()->to('/pembayaran')->with('success', 'Pembayaran berhasil ditambahkan.');
    }

    // Menampilkan form untuk mengedit pembayaran
    public function edit($id)
    {
        // Ambil data pembayaran berdasarkan ID
        $data['pembayaran'] = $this->pembayaranModel->find($id);

        // Tampilkan view dengan data pembayaran
        return view('pembayaran/edit', $data);
    }

    // Mengupdate data pembayaran
    public function update($id)
    {
        $data = [
            'id_siswa' => $this->request->getPost('id_siswa'),
            'jumlah_pembayaran' => $this->request->getPost('jumlah_pembayaran'),
            'metode_pembayaran' => $this->request->getPost('metode_pembayaran'),
            'tanggal_pembayaran' => $this->request->getPost('tanggal_pembayaran'),
        ];

        // Update data pembayaran di database
        $this->pembayaranModel->update($id, $data);

        // Redirect ke histori pembayaran setelah berhasil
        return redirect()->to('/pembayaran')->with('success', 'Pembayaran berhasil diupdate.');
    }

    // Menghapus data pembayaran
    public function hapus($id)
    {
        // Hapus data pembayaran dari database
        $this->pembayaranModel->delete($id);

        // Redirect ke histori pembayaran setelah berhasil
        return redirect()->to('/pembayaran')->with('success', 'Pembayaran berhasil dihapus.');
    }
}
