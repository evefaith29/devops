<?php

namespace App\Controllers;

use App\Models\HistoriPembayaranModel;

class HistoriPembayaran extends BaseController
{
    protected $historiPembayaranModel;

    public function __construct()
    {
        $this->historiPembayaranModel = new HistoriPembayaranModel();
    }

    // Menampilkan semua histori pembayaran
    public function index()
    {
        $data['histori_pembayaran'] = $this->historiPembayaranModel->getAllData();
        return view('histori_pembayaran/index', $data);
    }

    // Menampilkan form untuk menambah histori pembayaran
    public function tambah()
    {
        return view('histori_pembayaran/tambah');
    }

    // Menyimpan data histori pembayaran baru
    public function store()
    {
        $data = [
            'id_siswa' => $this->request->getPost('id_siswa'),
            'jumlah_pembayaran' => $this->request->getPost('jumlah_pembayaran'),
            'metode_pembayaran' => $this->request->getPost('metode_pembayaran'),
            'tanggal_pembayaran' => $this->request->getPost('tanggal_pembayaran'),
        ];

        $this->historiPembayaranModel->tambah($data);
        return redirect()->to('/histori_pembayaran')->with('success', 'Histori pembayaran berhasil ditambahkan.');
    }

    // Menampilkan form untuk mengedit histori pembayaran
    public function edit($id)
    {
        $data['histori'] = $this->historiPembayaranModel->getDataById($id);
        return view('histori_pembayaran/edit', $data);
    }

    // Memperbarui data histori pembayaran
    public function update($id)
    {
        $data = [
            'id_siswa' => $this->request->getPost('id_siswa'),
            'jumlah_pembayaran' => $this->request->getPost('jumlah_pembayaran'),
            'metode_pembayaran' => $this->request->getPost('metode_pembayaran'),
            'tanggal_pembayaran' => $this->request->getPost('tanggal_pembayaran'),
        ];

        $this->historiPembayaranModel->edit($data, $id);
        return redirect()->to('/histori_pembayaran')->with('success', 'Histori pembayaran berhasil diperbarui.');
    }

    // Menghapus histori pembayaran
    public function delete($id)
    {
        $this->historiPembayaranModel->hapus($id);
        return redirect()->to('/histori_pembayaran')->with('success', 'Histori pembayaran berhasil dihapus.');
    }
}
