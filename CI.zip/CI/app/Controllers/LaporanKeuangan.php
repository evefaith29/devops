<?php 

namespace App\Controllers;

use App\Models\PemasukanModel;
use App\Models\PengeluaranModel;

class LaporanKeuangan extends BaseController
{
    public function index()
    {
        $pemasukanModel = new PemasukanModel();
        $pengeluaranModel = new PengeluaranModel();

        // Ambil data pemasukan dan pengeluaran per bulan
        $pemasukanData = $pemasukanModel->select("DATE_FORMAT(tanggal, '%Y-%m') as bulan, SUM(jumlah_pemasukan) as total_pemasukan")
                                         ->groupBy("DATE_FORMAT(tanggal, '%Y-%m')")
                                         ->findAll();

        $pengeluaranData = $pengeluaranModel->select("DATE_FORMAT(tanggal, '%Y-%m') as bulan, SUM(jumlah_pengeluaran) as total_pengeluaran")
                                             ->groupBy("DATE_FORMAT(tanggal, '%Y-%m')")
                                             ->findAll();

        // Gabungkan data bulan dari pemasukan dan pengeluaran
        $bulanData = [];
        $semuaBulan = array_merge(
            array_column($pemasukanData, 'bulan'),
            array_column($pengeluaranData, 'bulan')
        );
        $semuaBulan = array_unique($semuaBulan);
        sort($semuaBulan);

        // Inisialisasi data per bulan dengan nilai default
        foreach ($semuaBulan as $bulan) {
            $bulanData[$bulan] = [
                'total_pemasukan' => 0,
                'total_pengeluaran' => 0
            ];
        }

        // Gabungkan data pemasukan
        foreach ($pemasukanData as $pemasukan) {
            $bulan = $pemasukan['bulan'];
            $bulanData[$bulan]['total_pemasukan'] = $pemasukan['total_pemasukan'];
        }

        // Gabungkan data pengeluaran
        foreach ($pengeluaranData as $pengeluaran) {
            $bulan = $pengeluaran['bulan'];
            $bulanData[$bulan]['total_pengeluaran'] = $pengeluaran['total_pengeluaran'];
        }

        // Hitung saldo akhir per bulan dengan logika saldo bulan sebelumnya
        $dataLaporan = [];
        $saldoSebelumnya = 0; // Saldo awal dimulai dari 0

        foreach ($bulanData as $bulan => $data) {
            // Saldo bulan ini = Saldo sebelumnya + pemasukan bulan ini - pengeluaran bulan ini
            $saldoAkhir = $saldoSebelumnya + $data['total_pemasukan'] - $data['total_pengeluaran'];

            $dataLaporan[] = [
                'bulan' => date("F Y", strtotime($bulan)), // Format menjadi teks bulan dan tahun
                'total_pemasukan' => $data['total_pemasukan'],
                'total_pengeluaran' => $data['total_pengeluaran'],
                'saldo_akhir' => $saldoAkhir
            ];

            // Update saldo sebelumnya untuk bulan berikutnya
            $saldoSebelumnya = $saldoAkhir;
        }

        // Kirim data ke view
        return view('laporan_keuangan', [
            'dataLaporan' => $dataLaporan,
            'totalKasSekolah' => $saldoSebelumnya // Total kas sekolah adalah saldo akhir bulan terakhir
        ]);
    }
}
