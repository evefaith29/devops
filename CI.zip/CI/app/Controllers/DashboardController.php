<?php

// app/Controllers/DashboardController.php

namespace App\Controllers;

use CodeIgniter\Controller;

class DashboardController extends Controller
{
    public function index()
    {
        $role = session()->get('role');

        if ($role === 'admin') {
            // Tampilkan halaman untuk Admin
        } elseif ($role === 'bendahara') {
            // Tampilkan halaman untuk Bendahara
        } elseif ($role === 'kepala_sekolah') {
            // Tampilkan halaman untuk Kepala Sekolah
        }

        return view('dashboard');
    }
}

