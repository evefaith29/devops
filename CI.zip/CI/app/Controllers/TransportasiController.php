<?php

namespace App\Controllers;

use App\Models\TransportasiModel;
use App\Models\PengeluaranModel;

class TransportasiController extends BaseController
{
    public function index()
    {
        $model = new TransportasiModel();
        $data['transportasi'] = $model->findAll();
        $totalBulanIni = $model->getTotalPengeluaranBulanIni();
        $data['total_pengeluaran_bulan_ini'] = $totalBulanIni ? $totalBulanIni['jumlah'] : 0;

        // Mendapatkan total pengeluaran seluruhnya
        $totalSeluruhnya = $model->getTotalPengeluaranSeluruhnya();
        $data['total_pengeluaran_seluruhnya'] = $totalSeluruhnya ? $totalSeluruhnya['jumlah'] : 0;
        return view('transportasi/index', $data);
    }

    public function create()
    {
        return view('transportasi/create');
    }

    public function store()
    {
        $model = new TransportasiModel();
    
        // Data yang akan disimpan di tabel transportasi
        $dataTransportasi = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_kegiatan' => $this->request->getPost('jenis_kegiatan'),
            'jumlah' => $this->request->getPost('jumlah'),
        ];
    
        // Simpan ke tabel transportasi
        $model->save($dataTransportasi);
    
        // Data yang akan disimpan di tabel pengeluaran_sekolah
        $dataPengeluaran = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_pengeluaran' => 'Transportasi: ' . $this->request->getPost('jenis_kegiatan'),
            'jumlah_pengeluaran' => $this->request->getPost('jumlah'),
        ];
    
        // Simpan ke tabel pengeluaran_sekolah
        $db = \Config\Database::connect();
        $db->table('pengeluaran_sekolah')->insert($dataPengeluaran);
    
        return redirect()->to('/transportasi');
    }
    

    public function edit($id)
    {
        $model = new TransportasiModel();
        $data['transportasi'] = $model->find($id);
        return view('transportasi/edit', $data);
    }

    public function update($id)
    {
        $model = new TransportasiModel();

        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_kegiatan' => $this->request->getPost('jenis_kegiatan'),
            'jumlah' => $this->request->getPost('jumlah'),
        ];

        $model->update($id, $data);
        return redirect()->to('/transportasi');
    }

    public function delete($id)
    {
        $model = new TransportasiModel();
        $model->delete($id);
        return redirect()->to('/transportasi');
    }
}
