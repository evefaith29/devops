<?php

namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel; // Pastikan model untuk user sudah ada

class ChangePasswordController extends Controller
{
    protected $userModel;

    public function __construct()
    {
        $this->userModel = new UserModel(); // Inisialisasi model UserModel
    }

    public function index()
    {
        $data = [
            'judul' => 'Ubah Password' // Tambahkan judul untuk tampilan
        ];
        return view('change_password', $data); // Pastikan Anda memiliki view ini
    }

    public function update()
    {
        // Ambil data dari request
        $oldPassword = $this->request->getPost('old_password');
        $newPassword = $this->request->getPost('new_password');
        $userId = session()->get('user_id'); // Misalnya Anda simpan user ID di session

        // Cek apakah password lama sesuai
        if ($this->userModel->verifyPassword($userId, $oldPassword)) {
            // Update password
            $this->userModel->updatePassword($userId, $newPassword);
            return redirect()->to('/change-password')->with('success', 'Password berhasil diubah.');
        } else {
            return redirect()->to('/change-password')->with('error', 'Password lama tidak sesuai.');
        }
    }
}
