<?php

namespace App\Controllers;

use App\Models\PenjualanPerlengkapanModel;
use CodeIgniter\Controller;

class PenjualanPerlengkapanController extends Controller
{
    public function index()
    {
        $model = new PenjualanPerlengkapanModel();
        $data['penjualan'] = $model->findAll();
        $total = $model->getTotalPemasukanBulanIni();
        $data['total_pemasukan'] = $total ? $total['jumlah'] : 0;
        return view('penjualan_perlengkapan/index', $data);
    }

    public function create()
    {
        return view('penjualan_perlengkapan/create');
    }

    public function store()
    {
        $penjualanModel = new PenjualanPerlengkapanModel();
        $pemasukanModel = new \App\Models\PemasukanModel();
    
        $jumlah = $this->request->getPost('jumlah');
    
        // Data untuk penjualan perlengkapan
        $penjualanData = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_perlengkapan' => $this->request->getPost('jenis_perlengkapan'),
            'jumlah' => $jumlah,
        ];
    
        // Simpan ke tabel penjualan_perlengkapan
        $penjualanModel->insert($penjualanData);
    
        // Data untuk pemasukan_sekolah
        $pemasukanData = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_pemasukan' => 'Penjualan Perlengkapan: ' . $this->request->getPost('jenis_perlengkapan'),
            'jumlah_pemasukan' => $jumlah,
        ];
    
        // Simpan ke tabel pemasukan_sekolah
        $pemasukanModel->insert($pemasukanData);
    
        return redirect()->to('/penjualan_perlengkapan');
    }
    

    public function edit($id)
    {
        $model = new PenjualanPerlengkapanModel();
        $data['penjualan'] = $model->find($id);
        return view('penjualan_perlengkapan/edit', $data);
    }

    public function update($id)
    {
        $model = new PenjualanPerlengkapanModel();
        $jumlah = $this->request->getPost('jumlah');

        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'jenis_perlengkapan' => $this->request->getPost('jenis_perlengkapan'),
            'jumlah' => $jumlah
        ];

        $model->update($id, $data);
        return redirect()->to('/penjualan_perlengkapan');
    }

    public function delete($id)
    {
        $model = new PenjualanPerlengkapanModel();
        $model->delete($id);
        return redirect()->to('/penjualan_perlengkapan');
    }
}
