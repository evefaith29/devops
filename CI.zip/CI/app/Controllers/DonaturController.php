<?php

namespace App\Controllers;

use App\Models\DonaturModel;

class DonaturController extends BaseController
{
    protected $donaturModel;

    public function __construct()
    {
        $this->donaturModel = new DonaturModel();
    }

    public function index()
    {
        $data['donatur'] = $this->donaturModel->findAll();
        return view('donatur/index', $data);
    }

    public function create()
    {
        return view('donatur/create');
    }

    public function store()
    {
        $this->donaturModel->save([
            'nama_donatur' => $this->request->getPost('nama_donatur'),
            'kontak_donatur' => $this->request->getPost('kontak_donatur'),
            'jumlah_sumbangan' => $this->request->getPost('jumlah_sumbangan'),
            'tanggal_sumbangan' => $this->request->getPost('tanggal_sumbangan'),
            'keterangan' => $this->request->getPost('keterangan'),
        ]);

        return redirect()->to('/donatur');
    }

    public function edit($id)
    {
        $data['donatur'] = $this->donaturModel->find($id);
        return view('donatur/edit', $data);
    }

    public function update($id)
    {
        $this->donaturModel->update($id, [
            'nama_donatur' => $this->request->getPost('nama_donatur'),
            'kontak_donatur' => $this->request->getPost('kontak_donatur'),
            'jumlah_sumbangan' => $this->request->getPost('jumlah_sumbangan'),
            'tanggal_sumbangan' => $this->request->getPost('tanggal_sumbangan'),
            'keterangan' => $this->request->getPost('keterangan'),
        ]);

        return redirect()->to('/donatur');
    }

    public function delete($id)
    {
        $this->donaturModel->delete($id);
        return redirect()->to('/donatur');
    }
}
