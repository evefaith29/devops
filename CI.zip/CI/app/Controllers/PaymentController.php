<?php

namespace App\Controllers;

use App\Models\PaymentModel;

class PaymentController extends BaseController
{
    protected $paymentModel;

    public function __construct()
    {
        $this->paymentModel = new PaymentModel();
    }

    public function index()
    {
        $data['payments'] = $this->paymentModel->findAll();
        return view('payments/index', $data);
    }

    public function create()
    {
        return view('payments/create');
    }

    public function store()
    {
        $this->paymentModel->save([
            'id_siswa' => $this->request->getPost('id_siswa'),
            'id_transaksi' => $this->request->getPost('id_transaksi'),
            'periode_bulan' => $this->request->getPost('periode_bulan'),
            'periode_tahun' => $this->request->getPost('periode_tahun'),
            'amount' => $this->request->getPost('amount'),
            'tanggal_pembayaran' => $this->request->getPost('tanggal_pembayaran'),
        ]);
        return redirect()->to('/payments')->with('success', 'Pembayaran berhasil ditambahkan.');
    }

    public function edit($id)
    {
        $data['payment'] = $this->paymentModel->find($id);
        if (!$data['payment']) {
            return redirect()->to('/payments')->with('error', 'Pembayaran tidak ditemukan.');
        }
        return view('payments/edit', $data);
    }

    public function update($id)
    {
        $this->paymentModel->update($id, [
            'id_siswa' => $this->request->getPost('id_siswa'),
            'id_transaksi' => $this->request->getPost('id_transaksi'),
            'periode_bulan' => $this->request->getPost('periode_bulan'),
            'periode_tahun' => $this->request->getPost('periode_tahun'),
            'amount' => $this->request->getPost('amount'),
            'tanggal_pembayaran' => $this->request->getPost('tanggal_pembayaran'),
        ]);
        return redirect()->to('/payments')->with('success', 'Pembayaran berhasil diperbarui.');
    }

    public function delete($id)
    {
        $this->paymentModel->delete($id);
        return redirect()->to('/payments')->with('success', 'Pembayaran berhasil dihapus.');
    }
}
