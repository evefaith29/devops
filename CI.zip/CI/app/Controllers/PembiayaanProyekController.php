<?php

namespace App\Controllers;

use App\Models\PembiayaanProyekModel;
use App\Models\PengeluaranModel;

class PembiayaanProyekController extends BaseController
{
    public function index()
    {
        $model = new PembiayaanProyekModel();
        $data['pembiayaan_proyek'] = $model->findAll();
        // Mendapatkan total pengeluaran bulan ini
        $totalBulanIni = $model->getTotalPengeluaranBulanIni();
        $data['total_pengeluaran_bulan_ini'] = $totalBulanIni ? $totalBulanIni['anggaran_terpakai'] : 0;

        // Mendapatkan total pengeluaran seluruhnya
        $totalSeluruhnya = $model->getTotalPengeluaranSeluruhnya();
        $data['total_pengeluaran_seluruhnya'] = $totalSeluruhnya ? $totalSeluruhnya['anggaran_terpakai'] : 0;
        return view('pembiayaan_proyek/index', $data);
    }

    public function create()
    {
        return view('pembiayaan_proyek/create');
    }

    public function store()
    {
        $model = new PembiayaanProyekModel();
    
        $sisa_anggaran = $model->calculateSisaAnggaran($this->request->getPost('anggaran_total'), $this->request->getPost('anggaran_terpakai'));
    
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_proyek' => $this->request->getPost('nama_proyek'),
            'anggaran_total' => $this->request->getPost('anggaran_total'),
            'anggaran_terpakai' => $this->request->getPost('anggaran_terpakai'),
            'sisa_anggaran' => $sisa_anggaran,
        ];
    
        // Simpan ke tabel pembiayaan_proyek
        $model->save($data);
    
        // Simpan juga ke tabel pengeluaran_sekolah
        $pengeluaranModel = new \App\Models\PengeluaranModel();
        $pengeluaranModel->save([
            'tanggal' => $data['tanggal'],
            'nama' => $data['nama'],
            'jenis_pengeluaran' => 'Pembiayaan Proyek - ' . $data['nama_proyek'],
            'jumlah_pengeluaran' => $data['anggaran_terpakai'],
        ]);
    
        return redirect()->to('/pembiayaan_proyek');
    }
    

    public function edit($id)
    {
        $model = new PembiayaanProyekModel();
        $data['pembiayaan_proyek'] = $model->find($id);
        return view('pembiayaan_proyek/edit', $data);
    }

    public function update($id)
    {
        $model = new PembiayaanProyekModel();
    
        $sisa_anggaran = $model->calculateSisaAnggaran($this->request->getPost('anggaran_total'), $this->request->getPost('anggaran_terpakai'));
        $data = [
            'tanggal' => $this->request->getPost('tanggal'),
            'nama' => $this->request->getPost('nama'),
            'nama_proyek' => $this->request->getPost('nama_proyek'),
            'anggaran_total' => $this->request->getPost('anggaran_total'),
            'anggaran_terpakai' => $this->request->getPost('anggaran_terpakai'),
            'sisa_anggaran' => $sisa_anggaran,
        ];
    
        // Update data di tabel pembiayaan_proyek
        $model->update($id, $data);
    
        // Update data di tabel pengeluaran_sekolah
        $pengeluaranModel = new \App\Models\PengeluaranModel();
        $pengeluaranModel->save([
            'tanggal' => $data['tanggal'],
            'nama' => $data['nama'],
            'jenis_pengeluaran' => 'Pembiayaan Proyek - ' . $data['nama_proyek'],
            'jumlah_pengeluaran' => $data['anggaran_terpakai'],
        ]);
    
        return redirect()->to('/pembiayaan_proyek');
    }
    

    public function delete($id)
    {
        $model = new PembiayaanProyekModel();
        $model->delete($id);
        return redirect()->to('/pembiayaan_proyek');
    }
}
