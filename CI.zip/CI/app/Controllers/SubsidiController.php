<?php

namespace App\Controllers;
use App\Models\SubsidiModel;
use App\Models\PemasukanModel;
use CodeIgniter\Controller;

class SubsidiController extends Controller
{
    public function index()
    {
        $model = new SubsidiModel();
        $data['subsidi'] = $model->findAll();
        $total = $model->getTotalPemasukanBulanIni();
        $data['total_pemasukan'] = $total ? $total['jumlah_subsidi'] : 0;
        return view('subsidi/index', $data);

    }

    public function create()
    {
        return view('subsidi/create');
    }

    public function store()
    {
        $subsidiModel = new SubsidiModel();
        $pemasukanModel = new PemasukanModel(); // Tambahkan ini

        $jumlahSubsidi = $this->request->getPost('jumlah_subsidi');
        $tanggal = $this->request->getPost('tanggal');
        $nama = $this->request->getPost('nama');

        // Simpan ke tabel subsidi
        $subsidiData = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'jumlah_subsidi' => $jumlahSubsidi,
        ];
        $subsidiModel->insert($subsidiData);

        // Simpan ke tabel pemasukan_sekolah
        $pemasukanData = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'jenis_pemasukan' => 'Subsidi',
            'jumlah_pemasukan' => $jumlahSubsidi,
        ];
        $pemasukanModel->insert($pemasukanData);

        return redirect()->to('/subsidi');
    }

    public function edit($id)
    {
        $model = new SubsidiModel();
        $subsidi = $model->find($id);
    
        // Jika data tidak ditemukan, redirect dengan pesan error
        if (!$subsidi) {
            return redirect()->to('/subsidi')->with('error', 'Data subsidi tidak ditemukan.');
        }
    
        $data['subsidi'] = $subsidi;
        return view('subsidi/edit', $data);
    }
    

    public function update($id)
    {
        $subsidiModel = new SubsidiModel();
        $pemasukanModel = new PemasukanModel(); // Tambahkan ini

        $jumlahSubsidi = $this->request->getPost('jumlah_subsidi');
        $tanggal = $this->request->getPost('tanggal');
        $nama = $this->request->getPost('nama');

        // Update tabel subsidi
        $subsidiData = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'jumlah_subsidi' => $jumlahSubsidi,
        ];
        $subsidiModel->update($id, $subsidiData);

        // Update tabel pemasukan_sekolah
        $pemasukanData = [
            'tanggal' => $tanggal,
            'nama' => $nama,
            'jenis_pemasukan' => 'Subsidi',
            'jumlah_pemasukan' => $jumlahSubsidi,
        ];
        $existingPemasukan = $pemasukanModel->where('tanggal', $tanggal)
                                             ->where('jenis_pemasukan', 'Subsidi')
                                             ->first();
        if ($existingPemasukan) {
            $pemasukanModel->update($existingPemasukan['id'], $pemasukanData);
        } else {
            $pemasukanModel->insert($pemasukanData);
        }

        return redirect()->to('/subsidi');
    }

    public function delete($id)
    {
        $model = new SubsidiModel();
        $model->delete($id);
        return redirect()->to('/subsidi');
    }
}
