<?php

namespace Config;

use CodeIgniter\Config\BaseConfig;

class Config extends BaseConfig
{
    public $sessionDriver = 'CodeIgniter\Session\Handlers\FileHandler'; // Driver untuk sesi
    public $sessionSavePath = ''; // Path untuk menyimpan sesi, gunakan sys_get_temp_dir() untuk lokasi default
    public $sessionExpire = 7200; // Waktu kedaluwarsa sesi dalam detik (2 jam)
    public $sessionMatchIP = false; // Cocokkan alamat IP untuk sesi
    public $sessionTimeToUpdate = 300; // Waktu sebelum ID sesi diperbarui
    public $sessionRegenerateDestroy = false; // Hancurkan sesi lama saat ID baru dibuat
}

// Pastikan tidak ada karakter tambahan di akhir file
