<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Tambah Pemasukan</h2>
    <form action="/pemasukan/store" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" required>
        </div>
        <div class="form-group">
            <label for="jenis_pemasukan">Jenis Pemasukan</label>
            <select class="form-control" id="jenis_pemasukan" name="jenis_pemasukan" required onchange="redirectToForm(this.value)">
                <option value="">Pilih Jenis Pemasukan</option>
                <option value="SPP">SPP</option>
                <option value="Pendaftaran">Pendaftaran</option>
                <option value="Subsidi">Subsidi</option>
                <option value="Donasi">Donasi</option>
                <option value="Penyewaan_Fasilitas">Penyewaan Fasilitas</option>
                <option value="Penjualan_Perlengkapan">Penjualan Perlengkapan</option>
                <option value="Dana_Yayasan">Dana Yayasan</option>
                <option value="Lain-lain">lain-lain</option>
            </select>
        </div>
    </form>
    <button class="btn btn-primary mt-3" onclick="document.querySelector('form').submit();">Simpan</button>
</div>

<script>
function redirectToForm(jenis) {
    if (jenis) {
        // Redirect to the specific form based on selected jenis_pemasukan
        window.location.href = '/' + jenis.replace(/\s+/g, '_').toLowerCase();
    }
}
</script>
<?= $this->endSection() ?>
