<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>

<div class="container mt-5">
    <h2 style="text-align: center; background-color: lightblue; border-bottom: 2px solid black;">
        Laporan Pemasukan Sekolah
    </h2>

    <?php
    // Mengelompokkan pemasukan berdasarkan bulan dan tahun
    $laporanBulanan = [];
    foreach ($pemasukan as $item) {
        $bulanTahun = date('F Y', strtotime($item['tanggal']));
        if (!isset($laporanBulanan[$bulanTahun])) {
            $laporanBulanan[$bulanTahun] = [
                'total' => 0,
                'detail' => []
            ];
        }
        $laporanBulanan[$bulanTahun]['total'] += $item['jumlah_pemasukan'];
        $laporanBulanan[$bulanTahun]['detail'][] = $item;
    }
    ?>

    <table class="table table-striped" id="tablePemasukan">
        <thead>
            <tr>
                <th>Bulan</th>
                <th>Total Pemasukan</th>
                <th>Detail Pemasukan</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($laporanBulanan as $bulan => $data): ?>
                <tr>
                    <td><?= $bulan; ?></td>
                    <td>Rp <?= number_format($data['total'], 0, ',', '.'); ?></td>
                    <td>
                        <button onclick="printLaporan('<?= $bulan; ?>')" class="btn btn-success btn-sm mb-2">Cetak Bulan Ini</button>
                        <div id="laporan-<?= str_replace(' ', '-', $bulan); ?>">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Jenis Pemasukan</th>
                                        <th>Jumlah Pemasukan</th>
                                        <th>Nama</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($data['detail'] as $detail): ?>
                                        <tr>
                                            <td class="tanggal"><?= date('d-m-Y H:i', strtotime($detail['tanggal'])); ?></td>
                                            <td class="jenis_pemasukan"><?= $detail['jenis_pemasukan'] ?? 'N/A'; ?></td>
                                            <td class="jumlah_pemasukan"><?= number_format($detail['jumlah_pemasukan'], 0, ',', '.'); ?></td>
                                            <td class="nama"><?= $detail['nama'] ?? 'N/A'; ?></td>
                                            <td>
                                                <button onclick="hapusPemasukan(<?= $detail['id']; ?>)" class="btn btn-danger btn-sm">Hapus</button> <!-- Tombol Hapus -->
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Script untuk menyimpan semua data pemasukan -->
<script>
function simpanSemuaPemasukan() {
    const rows = document.querySelectorAll("#tablePemasukan tbody tr");
    let dataPemasukan = [];
    rows.forEach(row => {
        let tanggalElement = row.querySelector(".tanggal");
        let jenisPemasukanElement = row.querySelector(".jenis_pemasukan");
        let jumlahPemasukanElement = row.querySelector(".jumlah_pemasukan");
        let namaElement = row.querySelector(".nama");
        // Pastikan elemen tidak null
        if (tanggalElement && jenisPemasukanElement && jumlahPemasukanElement) {
            let tanggal = tanggalElement.innerText;
            let jenis_pemasukan = jenisPemasukanElement.innerText;
            let jumlah_pemasukan = parseFloat(jumlahPemasukanElement.innerText.replace(/[^0-9.]/g, ''));
            let nama = namalElement.innerText;

            // Pastikan nilai jumlah_pemasukan valid
            if (!isNaN(jumlah_pemasukan)) {
                dataPemasukan.push({
                    tanggal: tanggal,
                    jenis_pemasukan: jenis_pemasukan,
                    jumlah_pemasukan: jumlah_pemasukan,
                    nama: nama
                });
            }
        } else {
            console.error('Elemen tidak ditemukan untuk baris:', row);
        }
    });

    fetch('/pemasukan/storeAll', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
        },
        body: JSON.stringify(dataPemasukan)
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message || 'Data berhasil disimpan');
        // Reload halaman setelah menyimpan
        location.reload();
    })
    .catch(error => console.error('Error:', error));
}
</script>

<style>
@media print {
    /* Sembunyikan elemen yang tidak perlu saat cetak */
    body * {
        visibility: hidden;
    }

    /* Tampilkan hanya bagian laporan yang dicetak */
    .container, .container * {
        visibility: visible;
    }

    /* Hanya cetak bagian dari laporan per bulan yang sesuai */
    .container {
        position: absolute;
        top: 0;
        left: 0;
    }

    /* Atur font dan tata letak untuk cetak */
    h2, .table thead {
        text-align: center;
        color: black;
    }
}
</style>

<script>
function printLaporan(bulan) {
    const laporan = document.getElementById(`laporan-${bulan.replace(' ', '-')}`);
    const originalContent = document.body.innerHTML;
    document.body.innerHTML = laporan.outerHTML;
    window.print();
    document.body.innerHTML = originalContent;
    location.reload(); // Reload halaman untuk mengembalikan tampilan
}
</script>

<script>
function hapusPemasukan(id) {
    if (confirm('Apakah Anda yakin ingin menghapus data ini?')) {
        fetch(`/pemasukan/delete/${id}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
            }
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message || 'Data berhasil dihapus');
            location.reload(); // Reload halaman setelah data dihapus
        })
        .catch(error => console.error('Error:', error));
    }
}
</script>

<?= $this->endSection() ?>
