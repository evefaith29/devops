<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit Penggajian</h2>
    <form action="/penggajian/update/<?= $penggajian['id']; ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $penggajian['tanggal']; ?>" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $penggajian['nama']; ?>" required>
        </div>
        <div class="form-group">
            <label for="nama_penerima">Nama Penerima</label>
            <input type="text" class="form-control" id="nama_penerima" name="nama_penerima" value="<?= $penggajian['nama_penerima']; ?>" required>
        </div>
        <div class="form-group">
            <label for="jabatan">Jabatan</label>
            <select class="form-control" id="jabatan" name="jabatan" required>
                <option value="guru" <?= $penggajian['jabatan'] == 'guru' ? 'selected' : ''; ?>>Guru</option>
                <option value="karyawan" <?= $penggajian['jabatan'] == 'karyawan' ? 'selected' : ''; ?>>Karyawan</option>
                <option value="staf" <?= $penggajian['jabatan'] == 'staf' ? 'selected' : ''; ?>>Staf</option>
            </select>
        </div>
        <div class="form-group">
            <label for="jumlah_gaji">Jumlah Gaji</label>
            <input type="number" class="form-control" id="jumlah_gaji" name="jumlah_gaji" value="<?= $penggajian['jumlah_gaji']; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Update</button>
    </form>
</div>
<?= $this->endSection() ?>
