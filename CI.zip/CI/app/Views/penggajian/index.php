<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Daftar Penggajian</h2>
    <div class="alert alert-info">
        Total Pengeluaran Bulan Ini: <?= number_format($total_pengeluaran_bulan_ini, 2, ',', '.') ?> 
    </div>
    <div class="alert alert-info">
        Total Pengeluaran: <?= number_format($total_pengeluaran_seluruhnya, 2, ',', '.') ?>
    </div>
    <a href="/penggajian/create" class="btn btn-primary mb-3">Tambah Penggajian</a>
<button type="button" class="btn btn-success mb-3" onclick="window.location.href='<?= base_url('penggajian/storeToPengeluaran') ?>'">Simpan</button>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Nama Penerima</th>
                <th>Jabatan</th>
                <th>Jumlah Gaji</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($penggajian as $item): ?>
            <tr>
                <td><?= $item['id']; ?></td>
                <td><?= $item['tanggal']; ?></td>
                <td><?= $item['nama']; ?></td>
                <td><?= $item['nama_penerima']; ?></td>
                <td><?= $item['jabatan']; ?></td>
                <td><?= $item['jumlah_gaji']; ?></td>

                <td>
                    <a href="/penggajian/edit/<?= $item['id']; ?>" class="btn btn-warning btn-sm">Edit</a>

                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
