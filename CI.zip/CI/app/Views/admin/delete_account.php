<!-- delete_account.php -->
<h2>Delete Account</h2>

<p>Are you sure you want to delete the account of <?= esc($user['username']) ?>?</p>

<form action="<?= base_url('admin/deleteAccount/' . $user['id']) ?>" method="post">
    <button type="submit" name="confirm" value="yes">Yes, Delete</button>
    <button type="submit" name="confirm" value="no">No, Cancel</button>
</form>
