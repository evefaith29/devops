<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histori Pembayaran</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container mt-5">
    <h1>Histori Pembayaran</h1>
    <div class="mb-3">
        <a href="<?= site_url('pembayaran/tambah') ?>" class="btn btn-success">Tambah Pembayaran</a>
    </div>
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>No</th>
                <th>ID Siswa</th>
                <th>Jumlah Pembayaran</th>
                <th>Metode Pembayaran</th>
                <th>Tanggal Pembayaran</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if(!empty($histori_pembayaran)) : ?>
                <?php $i = 1; foreach($histori_pembayaran as $pembayaran): ?>
                    <tr>
                        <td><?= $i++; ?></td>
                        <td><?= htmlspecialchars($pembayaran['id_siswa']); ?></td>
                        <td><?= htmlspecialchars($pembayaran['jumlah_pembayaran']); ?></td>
                        <td><?= htmlspecialchars($pembayaran['metode_pembayaran']); ?></td>
                        <td><?= htmlspecialchars($pembayaran['tanggal_pembayaran']); ?></td>
                        <td>
                            <a href="<?= site_url('pembayaran/edit/' . $pembayaran['id']) ?>" class="btn btn-warning btn-sm">Edit</a>
                            <a href="<?= site_url('pembayaran/hapus/' . $pembayaran['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus pembayaran ini?');">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" class="text-center">Tidak ada histori pembayaran.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
