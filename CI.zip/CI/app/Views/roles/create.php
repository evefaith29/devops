<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($judul) ? htmlspecialchars($judul) : 'Ubah Pengguna'; ?></title>
    <link href="assets/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="assets/css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body>

    <div class="container-fluid">
        <h1 class="h3 mb-4 text-gray-800"><?= isset($judul) ? htmlspecialchars($judul) : 'Ubah Pengguna'; ?></h1>

        <?php if (isset($pengguna)): ?>
            <form action="/pengguna/update/<?= htmlspecialchars($pengguna['id']); ?>" method="post">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th scope="col">Field</th>
                            <th scope="col">Input</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><label for="username">Username</label></td>
                            <td>
                                <input type="text" id="username" name="username" class="form-control" 
                                value="<?= htmlspecialchars($pengguna['username']); ?>" required>
                            </td>
                        </tr>
                        <tr>
                            <td><label for="password">Password (Kosongkan jika tidak ingin mengubah)</label></td>
                            <td>
                                <input type="password" id="password" name="password" class="form-control">
                            </td>
                        </tr>
                        <tr>
                            <td><label for="peran">Peran</label></td>
                            <td>
                                <select id="peran" name="peran" class="form-control" required>
                                    <option value="admin" <?= (isset($pengguna['peran']) && $pengguna['peran'] == 'admin') ? 'selected' : ''; ?>>Admin</option>
                                    <option value="user" <?= (isset($pengguna['peran']) && $pengguna['peran'] == 'user') ? 'selected' : ''; ?>>User</option>
                                </select>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <button type="submit" class="btn btn-primary">Update</button>
            </form>
        <?php else: ?>
            <div class="alert alert-danger">Pengguna tidak ditemukan.</div>
        <?php endif; ?>
    </div>

    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/sb-admin-2.min.js"></script>
</body>
</html>
