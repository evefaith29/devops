<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Budget</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { color: #333; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .btn { display: inline-block; margin-top: 20px; padding: 10px 15px; color: #fff; background-color: #007bff; border: none; border-radius: 5px; text-decoration: none; }
        .btn:hover { background-color: #0056b3; }
    </style>
</head>
<body>
    <h1>Data Budget</h1>
    <a href="<?= site_url('budget/create') ?>" class="btn">Tambah Budget</a>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nama Budget</th>
                <th>Jumlah Rencana</th>
                <th>Jumlah Aktual</th>
                <th>Tahun Budget</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($budgets)): ?>
                <?php foreach ($budgets as $item): ?>
                    <tr>
                        <td><?php echo $item['budget_id']; ?></td>
                        <td><?php echo $item['budget_name']; ?></td>
                        <td><?php echo number_format($item['planned_amount'], 2); ?></td>
                        <td><?php echo number_format($item['actual_amount'], 2); ?></td>
                        <td><?php echo $item['budget_year']; ?></td>
                        <td>
                            <a href="<?= site_url('budget/edit/' . $item['budget_id']) ?>" class="btn">Edit</a>
                            <a href="<?= site_url('budget/delete/' . $item['budget_id']) ?>" class="btn" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6">Tidak ada data budget.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
