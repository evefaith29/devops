// app/Views/pembelian_barang/index.php

<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Data Pembelian Barang</h2>
    <a href="/pembelian_barang/create" class="btn btn-primary mb-3">Tambah Pembelian Barang</a>
    <div class="alert alert-info">
        Total Pengeluaran Bulan Ini: <?= number_format($total_pengeluaran_bulan_ini, 2, ',', '.') ?> 
    </div>

    <div class="alert alert-info">
        Total Pengeluaran: <?= number_format($total_pengeluaran_seluruhnya, 2, ',', '.') ?>
    </div>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Nama Barang</th>
                <th>Jumlah Barang</th>
                <th>Harga Satuan</th>
                <th>Total Harga</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($pembelian_barang as $barang): ?>
                <tr>
                    <td><?= $barang['id'] ?></td>
                    <td><?= $barang['tanggal'] ?></td>
                    <td><?= $barang['nama'] ?></td>
                    <td><?= $barang['nama_barang'] ?></td>
                    <td><?= $barang['jumlah_barang'] ?></td>
                    <td><?= number_format($barang['harga_satuan'], 2) ?></td>
                    <td><?= number_format($barang['total_harga'], 2) ?></td>
                    <td>
                        <a href="/pembelian_barang/edit/<?= $barang['id'] ?>" class="btn btn-warning">Edit</a>
                        <form action="/pembelian_barang/delete/<?= $barang['id'] ?>" method="post" style="display:inline;">
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
