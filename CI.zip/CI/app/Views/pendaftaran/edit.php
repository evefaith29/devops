<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit Data Pendaftaran</h2>
    <form action="/pendaftaran/update/<?= $pendaftaran['id'] ?>" method="post">
        <!-- Form fields sama seperti di create.php -->
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= old('tanggal', $pendaftaran['tanggal']) ?>" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= old('nama', $pendaftaran['nama']) ?>" required>
        </div>
        <div class="form-group">
            <label for="nama_siswa">Nama Siswa</label>
            <input type="text" class="form-control" id="nama_siswa" name="nama_siswa" value="<?= old('nama_siswa', $pendaftaran['nama_siswa']) ?>" required>
        </div>
        
        <!-- Form untuk 'Jumlah yang Harus Dibayar' -->
        <div class="form-group">
            <label for="jumlah_yang_harus_dibayar">Jumlah yang Harus Dibayar</label>
            <input type="number" class="form-control" id="jumlah_yang_harus_dibayar" name="jumlah_yang_harus_dibayar" value="<?= old('jumlah_yang_harus_dibayar', $pendaftaran['jumlah_yang_harus_dibayar']) ?>" readonly>
        </div>

        <div class="form-group">
            <label for="jumlah_yang_dibayar">Jumlah yang Dibayar</label>
            <input type="number" class="form-control" id="jumlah_yang_dibayar" name="jumlah_yang_dibayar" value="<?= old('jumlah_yang_dibayar', $pendaftaran['jumlah_yang_dibayar']) ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Update</button>
    </form>
</div>
<?= $this->endSection() ?>
