<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Invoices</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Data Invoices</h2>
        <a href="<?= site_url('invoices/tambah') ?>" class="btn btn-success mb-3">Tambah Invoice</a>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Invoice Number</th>
                    <th>Invoice Date</th>
                    <th>Due Date</th>
                    <th>Total Amount</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($invoices as $invoice): ?>
                <tr>
                    <td><?= $invoice['invoice_id'] ?></td>
                    <td><?= $invoice['user_id'] ?></td>
                    <td><?= $invoice['invoice_number'] ?></td>
                    <td><?= $invoice['invoice_date'] ?></td>
                    <td><?= $invoice['due_date'] ?></td>
                    <td><?= $invoice['total_amount'] ?></td>
                    <td><?= $invoice['status'] ?></td>
                    <td>
                        <a href="<?= site_url('invoices/edit/' . $invoice['invoice_id']) ?>" class="btn btn-warning">Edit</a>
                        <a href="<?= site_url('invoices/hapus/' . $invoice['invoice_id']) ?>" class="btn btn-danger">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
