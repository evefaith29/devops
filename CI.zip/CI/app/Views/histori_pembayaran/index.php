<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histori Pembayaran</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Histori Pembayaran</h1>
        <a href="<?= site_url('histori_pembayaran/tambah') ?>" class="btn btn-primary mb-3">Tambah Pembayaran</a>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>ID Siswa</th>
                    <th>Jumlah Pembayaran</th>
                    <th>Metode Pembayaran</th>
                    <th>Tanggal Pembayaran</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($histori_pembayaran as $histori): ?>
                    <tr>
                        <td><?= $histori['id'] ?></td>
                        <td><?= $histori['id_siswa'] ?></td>
                        <td><?= number_format($histori['jumlah_pembayaran'], 2) ?></td>
                        <td><?= $histori['metode_pembayaran'] ?></td>
                        <td><?= date('Y-m-d', strtotime($histori['tanggal_pembayaran'])) ?></td>
                        <td>
                            <a href="<?= site_url('histori_pembayaran/edit/' . $histori['id']) ?>" class="btn btn-warning">Edit</a>
                            <a href="<?= site_url('histori_pembayaran/delete/' . $histori['id']) ?>" class="btn btn-danger" onclick="return confirm('Anda yakin ingin menghapus?')">Delete</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
