<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Histori Pembayaran</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Tambah Histori Pembayaran</h1>
        <form action="<?= site_url('histori_pembayaran/store') ?>" method="post">
            <div class="form-group">
                <label for="id_siswa">ID Siswa:</label>
                <input type="number" id="id_siswa" name="id_siswa" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="jumlah_pembayaran">Jumlah Pembayaran:</label>
                <input type="text" id="jumlah_pembayaran" name="jumlah_pembayaran" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="metode_pembayaran">Metode Pembayaran:</label>
                <input type="text" id="metode_pembayaran" name="metode_pembayaran" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="tanggal_pembayaran">Tanggal Pembayaran:</label>
                <input type="date" id="tanggal_pembayaran" name="tanggal_pembayaran" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
        </form>
    </div>
</body>
</html>
