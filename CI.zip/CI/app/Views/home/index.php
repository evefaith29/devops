<div class="container mt-4 mb-5" style="background-color: rgba(255, 255, 255, 0.8); padding: 20px; border-radius: 5px;">
    <h2 style="text-align: center; background-color: lightblue;">
        SMK ADVENT TONGUTE GOIN
    </h2>
    <p class="mb-4 text-center">Selamat datang di <b>SMK Tongute Goin</b>. Kami adalah sekolah dengan komitmen tinggi untuk menyediakan pendidikan berkualitas.</p>

    <h3 class="font-weight-bold text-center">Visi</h3>
    <p class="text-center">Pendidikan Advent menetapkan standard untuk berkarakter seperti Yesus, berprestasi dan trampil dalam ilmu pengetahuan dan teknologi, seni, serta kreatif, produktif dan mandiri.</p>

    <h3 class="font-weight-bold text-center">Misi</h3>
    <p class="text-center">Misi Pendidikan Advent yaitu untuk mewujudkan Pendidikan Advent yang beriman dan suka melayani; mengembangkan kemampuan murid agar kreatif, produktif dan mandiri.</p>


    <?php if ($role == 'admin'): ?>
    <?php elseif ($role == 'bendahara'): ?>
    <?php elseif ($role == 'kepala_sekolah'): ?>
    <?php else: ?>
        <h3 class="text-center">Akses Tidak Dikenal</h3>
        <p>Silakan hubungi administrator untuk memperbaiki masalah ini.</p>
    <?php endif; ?>

</div>
