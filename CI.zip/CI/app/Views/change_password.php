<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $judul; ?></title>
</head>
<body>
    <h2><?= $judul; ?></h2>

    <?php if (session()->getFlashdata('success')): ?>
        <p style="color: green;"><?= session()->getFlashdata('success'); ?></p>
    <?php elseif (session()->getFlashdata('error')): ?>
        <p style="color: red;"><?= session()->getFlashdata('error'); ?></p>
    <?php endif; ?>

    <form action="<?= base_url('change-password/update'); ?>" method="post">
        <label for="old_password">Password Lama:</label>
        <input type="password" name="old_password" id="old_password" required>

        <label for="new_password">Password Baru:</label>
        <input type="password" name="new_password" id="new_password" required>

        <button type="submit">Ubah Password</button>
    </form>
</body>
</html>
