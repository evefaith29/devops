<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit Hutang Sekolah</h2>
    <form action="/hutang_sekolah/update/<?= $hutang_sekolah['id'] ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $hutang_sekolah['tanggal'] ?>" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $hutang_sekolah['nama'] ?>" required>
        </div>
        <div class="form-group">
            <label for="pemberi_hutang">Pemberi Hutang</label>
            <input type="text" class="form-control" id="pemberi_hutang" name="pemberi_hutang" value="<?= $hutang_sekolah['pemberi_hutang'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jumlah_hutang">Jumlah Hutang</label>
            <input type="number" class="form-control" id="jumlah_hutang" name="jumlah_hutang" value="<?= $hutang_sekolah['jumlah_hutang'] ?>" required>
        </div>
        <div class="form-group">
            <label for="dibayar">Jumlah Dibayar</label>
            <input type="number" class="form-control" id="dibayar" name="dibayar" value="<?= $hutang_sekolah['dibayar'] ?>" required>
        </div>
        <div class="form-group">
            <label for="tanggal_jatuh_tempo">Tanggal Jatuh Tempo</label>
            <input type="date" class="form-control" id="tanggal_jatuh_tempo" name="tanggal_jatuh_tempo" value="<?= $hutang_sekolah['tanggal_jatuh_tempo'] ?>" required>
        </div>
        <button type="submit" class="btn btn-warning mt-3">Update</button>
    </form>
</div>
<?= $this->endSection() ?>
