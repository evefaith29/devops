<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit Acara Sekolah</h2>
    <form action="/acara_sekolah/update/<?= $acara['id'] ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $acara['tanggal'] ?>" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="name" class="form-control" id="nama" name="nama" value="<?= $acara['nama'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jenis_acara">Jenis Acara</label>
            <input type="text" class="form-control" id="jenis_acara" name="jenis_acara" value="<?= $acara['jenis_acara'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jumlah">Jumlah</label>
            <input type="number" class="form-control" id="jumlah" name="jumlah" value="<?= $acara['jumlah'] ?>" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Update</button>
    </form>
</div>
<?= $this->endSection() ?>
