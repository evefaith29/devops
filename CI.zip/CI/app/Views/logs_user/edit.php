<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Log</title>
    <!-- Link ke Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Edit Log</h1>
        <form action="/logs/update/<?= $log['id'] ?>" method="post">
            <div class="form-group">
                <label for="user_id">User ID:</label>
                <input type="number" class="form-control" name="user_id" id="user_id" value="<?= $log['id_pengguna'] ?>" required>
            </div>
            <div class="form-group">
                <label for="action">Aksi:</label>
                <input type="text" class="form-control" name="action" id="action" value="<?= $log['aksi'] ?>" required>
            </div>
            <div class="form-group">
                <label for="table_name">Nama Tabel:</label>
                <input type="text" class="form-control" name="table_name" id="table_name" value="<?= $log['nama_tabel'] ?>" required>
            </div>
            <div class="form-group">
                <label for="transaction_id">ID Catatan:</label>
                <input type="number" class="form-control" name="transaction_id" id="transaction_id" value="<?= $log['id_catatan'] ?>" required>
            </div>
            <div class="text-center">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
        <div class="text-center mt-3">
        </div>
    </div>

    <!-- Link ke Bootstrap JS dan dependensinya (jika perlu) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
