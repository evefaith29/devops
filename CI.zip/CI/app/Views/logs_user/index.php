<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        table {
            width: 100%;
            margin: 20px 0;
        }
        .action-buttons a {
            margin: 0 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Logs</h1>
        <div class="text-center mb-4">
            <a href="/logs/create" class="btn btn-primary">Tambah Log</a>
        </div>
        <table class="table table-bordered">
            <thead class="thead-light">
                <tr>
                    <th>ID</th>
                    <th>User ID</th>
                    <th>Aksi</th>
                    <th>Nama Tabel</th>
                    <th>ID Catatan</th>
                    <th>Timestamp</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($logs)): ?>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= esc($log['id']) ?></td>
                            <td><?= esc($log['id_pengguna']) ?></td>
                            <td><?= esc($log['aksi']) ?></td>
                            <td><?= esc($log['nama_tabel']) ?></td>
                            <td><?= esc($log['id_catatan']) ?></td>
                            <td><?= esc($log['timestamp']) ?></td>
                            <td class="action-buttons">
                                <a href="/logs/edit/<?= esc($log['id']) ?>" class="btn btn-warning btn-sm">Edit</a>
                                <a href="/logs/delete/<?= esc($log['id']) ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="7" class="text-center">Tidak ada log yang ditemukan.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
