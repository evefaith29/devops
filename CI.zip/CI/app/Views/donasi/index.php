<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Daftar Donasi</h2>
    <div class="alert alert-info">
        Total Pemasukan Bulan Ini: <?= number_format($total_pemasukan, 2, ',', '.') ?> 
    </div>
    <a href="/donasi/create" class="btn btn-primary mb-3">Tambah Donasi</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Asal Donasi</th>
                <th>Jumlah Donasi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($donasi as $d): ?>
                <tr>
                    <td><?= $d['tanggal'] ?></td>
                    <td><?= $d['nama'] ?></td>
                    <td><?= $d['asal_donasi'] ?></td>
                    <td><?= $d['jumlah_donasi'] ?></td>
                    <td>
                        <a href="/donasi/edit/<?= $d['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="/donasi/delete/<?= $d['id'] ?>" class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
