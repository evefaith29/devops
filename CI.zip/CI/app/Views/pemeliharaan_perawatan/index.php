<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Data Pemeliharaan dan Perawatan</h2>
    <div class="alert alert-info">
        Total Pengeluaran Bulan Ini: <?= number_format($total_pengeluaran_bulan_ini, 2, ',', '.') ?> 
    </div>
    <div class="alert alert-info">
        Total Pengeluaran: <?= number_format($total_pengeluaran_seluruhnya, 2, ',', '.') ?>
    </div>
    <a href="/pemeliharaan_perawatan/create" class="btn btn-primary mb-3">Tambah Pemeliharaan</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Jenis Pemeliharaan</th>
                <th>Jumlah</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($pemeliharaan_perawatan as $item): ?>
                <tr>
                    <td><?= $item['id'] ?></td>
                    <td><?= $item['tanggal'] ?></td>
                    <td><?= $item['nama'] ?></td>
                    <td><?= $item['jenis_pemeliharaan'] ?></td>
                    <td><?= $item['jumlah'] ?></td>
                    <td>
                        <a href="/pemeliharaan_perawatan/edit/<?= $item['id'] ?>" class="btn btn-warning">Edit</a>
                        <form action="/pemeliharaan_perawatan/delete/<?= $item['id'] ?>" method="post" style="display:inline;">
                            <button type="submit" class="btn btn-danger">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
