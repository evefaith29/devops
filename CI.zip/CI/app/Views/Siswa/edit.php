<!-- View: app/Views/siswa/edit.php -->
<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800"><?= esc($judul); ?></h1> <!-- Escaping untuk keamanan XSS -->

    <!-- Tampilkan pesan sukses jika ada -->
    <?= session()->getFlashdata('message') ? '<div class="alert alert-success">' . esc(session()->getFlashdata('message')) . '</div>' : ''; ?>

    <!-- Tampilkan pesan error jika ada -->
    <?= session()->getFlashdata('err') ? '<div class="alert alert-danger">' . esc(session()->getFlashdata('err')) . '</div>' : ''; ?>

    <form action="<?= base_url('siswa/edit/' . $siswa['id']); ?>" method="POST">
        <!-- Menambahkan token CSRF untuk keamanan -->
        <?= csrf_field(); ?>

        <input type="hidden" name="id" value="<?= esc($siswa['id']); ?>">

        <div class="form-group">
            <label for="name">Nama Siswa</label>
            <!-- Menggunakan old() untuk mempertahankan input saat validasi gagal -->
            <input type="text" class="form-control" id="name" name="name" value="<?= old('name', esc($siswa['name'])); ?>" required>
        </div>

        <div class="form-group">
            <label for="payment">Pembayaran</label>
            <!-- Menggunakan old() untuk mempertahankan input saat validasi gagal -->
            <input type="text" class="form-control" id="payment" name="payment" value="<?= old('payment', esc($siswa['payment'])); ?>" required>
        </div>

        <button type="submit" class="btn btn-primary">Simpan</button>
        <a href="<?= base_url('siswa'); ?>" class="btn btn-secondary">Kembali</a>
    </form>
</div>
