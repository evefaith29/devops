<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2 style="text-align: center; background-color: lightblue; border-bottom: 2px solid black;">
        Laporan Keuangan Sekolah
    </h2>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Bulan</th>
                <th>Total Pemasukan</th>
                <th>Total Pengeluaran</th>
                <th>Saldo Akhir</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dataLaporan as $row): ?>
                <tr>
                    <td><?= $row['bulan'] ?></td>
                    <td><?= number_format($row['total_pemasukan'], 0, ',', '.') ?></td>
                    <td><?= number_format($row['total_pengeluaran'], 0, ',', '.') ?></td>
                    <td><?= number_format($row['saldo_akhir'], 0, ',', '.') ?></td>
                </tr>
            <?php endforeach; ?>
            <tr>
                <td colspan="3" class="text-right font-weight-bold">Total Kas Sekolah :</td>
                <td><?= number_format($totalKasSekolah, 0, ',', '.') ?></td>
            </tr>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
