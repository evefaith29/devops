<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit Pengeluaran</h2>
    <form action="/pengeluaran/update/<?= $pengeluaran['id']; ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $pengeluaran['tanggal']; ?>" required>
        </div>
        <div class="form-group">
            <label for="jenis_pengeluaran">Jenis Pengeluaran</label>
            <select class="form-control" id="jenis_pengeluaran" name="jenis_pengeluaran" required>
                <option value="Penggajian" <?= $pengeluaran['jenis_pengeluaran'] == 'Penggajian' ? 'selected' : ''; ?>>Penggajian</option>
                <option value="Pembelian Barang" <?= $pengeluaran['jenis_pengeluaran'] == 'Pembelian Barang' ? 'selected' : ''; ?>>Pembelian Barang</option>
                <option value="Pemeliharaan" <?= $pengeluaran['jenis_pengeluaran'] == 'Pemeliharaan' ? 'selected' : ''; ?>>Pemeliharaan</option>
                <option value="Tagihan" <?= $pengeluaran['jenis_pengeluaran'] == 'Tagihan' ? 'selected' : ''; ?>>Tagihan</option>
                <option value="Acara Sekolah" <?= $pengeluaran['jenis_pengeluaran'] == 'Acara Sekolah' ? 'selected' : ''; ?>>Acara Sekolah</option>
                <option value="Pelatihan Guru" <?= $pengeluaran['jenis_pengeluaran'] == 'Pelatihan Guru' ? 'selected' : ''; ?>>Pelatihan Guru</option>
                <option value="Transportasi" <?= $pengeluaran['jenis_pengeluaran'] == 'Transportasi' ? 'selected' : ''; ?>>Transportasi</option>
                <option value="Hutang Sekolah" <?= $pengeluaran['jenis_pengeluaran'] == 'Hutang Sekolah' ? 'selected' : ''; ?>>Hutang Sekolah</option>
                <option value="Pembiayaan Proyek" <?= $pengeluaran['jenis_pengeluaran'] == 'Pembiayaan Proyek' ? 'selected' : ''; ?>>Pembiayaan Proyek</option>
                <option value="Lain-lain" <?= $pengeluaran['jenis_pengeluaran'] == 'Lain-lain' ? 'selected' : ''; ?>>Lain-lain</option>
            </select>

        </div>
        <button type="submit" class="btn btn-primary mt-3">Update</button>
    </form>
</div>
<?= $this->endSection() ?>
