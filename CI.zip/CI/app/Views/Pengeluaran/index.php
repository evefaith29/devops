<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2 style="text-align: center; background-color: lightblue; border-bottom: 2px solid black;">
        Laporan Pengeluaran Sekolah
    </h2>

    <!-- Tombol untuk menambah dan menyimpan semua data pengeluaran -->

    <?php
    // Mengelompokkan pengeluaran berdasarkan bulan dan tahun
    $laporanBulanan = [];
    foreach ($pengeluaran as $item) {
        $bulanTahun = date('F Y', strtotime($item['tanggal']));
        if (!isset($laporanBulanan[$bulanTahun])) {
            $laporanBulanan[$bulanTahun] = [
                'total' => 0,
                'detail' => []
            ];
        }
        $laporanBulanan[$bulanTahun]['total'] += $item['jumlah_pengeluaran'];
        $laporanBulanan[$bulanTahun]['detail'][] = $item;
    }
    ?>

    <table id="tablePengeluaran" class="table table-bordered mt-4">
        <thead>
            <tr>
                <th>Bulan</th>
                <th>Total Pengeluaran</th>
                <th>Detail Pengeluaran</th>
                
            </tr>
        </thead>
        <tbody>
        <?php foreach ($laporanBulanan as $bulan => $data): ?>
            <tr>
                <td><?= $bulan; ?></td>
                <td>Rp <?= number_format($data['total'], 0, ',', '.'); ?></td>
                <td>
                    <button onclick="printLaporan('<?= $bulan; ?>')" class="btn btn-success btn-sm mb-2">Cetak Bulan Ini</button>
                    <div id="laporan-<?= str_replace(' ', '-', $bulan); ?>">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Jenis Pengeluaran</th>
                                    <th>Jumlah Pengeluaran</th>
                                    <th>Nama</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($data['detail'] as $detail): ?>
                                    <tr>
                                        <td class="tanggal"><?= date('Y-m-d', strtotime($detail['tanggal'])); ?></td>
                                        <td class="jenis_pengeluaran"><?= $detail['jenis_pengeluaran'] ?? 'N/A'; ?></td>
                                        <td class="jumlah_pengeluaran"><?= $detail['jumlah_pengeluaran']; ?></td>
                                        <td class="nama"><?= $detail['nama'] ?? 'N/A'; ?></td>
                                        <td>
                                            <button onclick="hapusPengeluaran(<?= $detail['id']; ?>)" class="btn btn-danger btn-sm">Hapus</button> <!-- Tombol Hapus -->
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Script untuk menyimpan semua data pengeluaran -->
<script>
function simpanSemuaPengeluaran() {
    const rows = document.querySelectorAll("#tablePengeluaran tbody tr");
    let dataPengeluaran = [];
    rows.forEach(row => {
        let tanggalElement = row.querySelector(".tanggal");
        let jenisPengeluaranElement = row.querySelector(".jenis_pengeluaran");
        let jumlahPengeluaranElement = row.querySelector(".jumlah_pengeluaran");

        console.log(tanggalElement, jenisPengeluaranElement, jumlahPengeluaranElement); // Tambahkan ini untuk debug

        // Pastikan elemen tidak null
        if (tanggalElement && jenisPengeluaranElement && jumlahPengeluaranElement) {
            let tanggal = tanggalElement.innerText;
            let jenis_pengeluaran = jenisPengeluaranElement.innerText;
            let jumlah_pengeluaran = parseFloat(jumlahPengeluaranElement.innerText.replace(/[^0-9.]/g, ''));

            // Pastikan nilai jumlah_pengeluaran valid
            if (!isNaN(jumlah_pengeluaran)) {
                dataPengeluaran.push({
                    tanggal: tanggal,
                    jenis_pengeluaran: jenis_pengeluaran,
                    jumlah_pengeluaran: jumlah_pengeluaran
                });
            }
        } else {
            console.error('Elemen tidak ditemukan untuk baris:', row);
        }
    });

    console.log(dataPengeluaran); // Log data untuk debug

    fetch('/pengeluaran/storeAll', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': '<?= csrf_hash() ?>'
        },
        body: JSON.stringify(dataPengeluaran)
    })
    .then(response => response.json())
    .then(data => {
        console.log('Respons dari server:', data);
        alert(data.message || 'Data berhasil disimpan');
        // Reload halaman setelah menyimpan
        location.reload();
    })
    .catch(error => console.error('Error:', error));
}

</script>


<style>
@media print {
    /* Sembunyikan tombol dan elemen yang tidak perlu di cetak */
    .btn, .form-group, .table th:nth-child(5), .table td:nth-child(5) {
        display: none;
    }

    /* Atur format tabel agar lebih terlihat jelas saat dicetak */
    h2, h3 {
        text-align: center;
        color: black;
        border: none;
        background-color: transparent;
    }

    /* Menghilangkan margin untuk cetakan */
    body, .container {
        margin: 0;
        padding: 0;
    }

    /* Sesuaikan ukuran font atau warna jika perlu */
    .table {
        font-size: 14px;
    }
}
</style>

<script>
function printLaporan(bulan) {
    const laporan = document.getElementById(`laporan-${bulan.replace(' ', '-')}`);
    const originalContent = document.body.innerHTML;
    document.body.innerHTML = laporan.outerHTML;
    window.print();
    document.body.innerHTML = originalContent;
    location.reload(); // Reload halaman untuk mengembalikan tampilan
}
</script>


<?= $this->endSection() ?>
