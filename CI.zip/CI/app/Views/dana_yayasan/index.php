<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Daftar Dana Yayasan</h2>
    <div class="alert alert-info">
        Total Pemasukan Bulan Ini: <?= number_format($total_pemasukan, 2, ',', '.') ?> 
    </div>
    <a href="/dana_yayasan/create" class="btn btn-primary mb-3">Tambah Dana Yayasan</a>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Tanggal</th>
                <th>Nama</th>
                <th>Jumlah</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($dana as $d): ?>
                <tr>
                    <td><?= $d['tanggal'] ?></td>
                    <td><?= $d['nama'] ?></td>
                    <td><?= $d['jumlah'] ?></td>
                    <td>
                        <a href="/dana_yayasan/edit/<?= $d['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                        <a href="/dana_yayasan/delete/<?= $d['id'] ?>" class="btn btn-danger btn-sm">Hapus</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?= $this->endSection() ?>
