<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit Subsidi</h2>
    <?php if (isset($subsidi)): ?>
    <form action="/subsidi/update/<?= $subsidi['id'] ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $subsidi['tanggal'] ?>" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $subsidi['nama'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jumlah_subsidi">Jumlah Subsidi</label>
            <input type="number" class="form-control" id="jumlah_subsidi" name="jumlah_subsidi" value="<?= $subsidi['jumlah_subsidi'] ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
    </form>
    <?php else: ?>
        <p>Data subsidi tidak ditemukan.</p>
    <?php endif; ?>
</div>
<?= $this->endSection() ?>
