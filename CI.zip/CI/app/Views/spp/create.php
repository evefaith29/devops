<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Tambah SPP</h2>
    <form action="/spp/store" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" required>
        </div>
        <div class="form-group">
            <label for="nama_siswa">Nama Siswa</label>
            <input type="text" class="form-control" id="nama_siswa" name="nama_siswa" required>
        </div>
        <div class="form-group">
            <label for="jumlah_yang_harus_dibayar">Jumlah yang Harus Dibayar</label>
            <input type="number" class="form-control" id="jumlah_yang_harus_dibayar" name="jumlah_yang_harus_dibayar" value="<?= $jumlah_default ?>" readonly required>
        </div>


        <div class="form-group">
            <label for="jumlah_dibayar">Jumlah Dibayar</label>
            <input type="number" class="form-control" id="jumlah_dibayar" name="jumlah_dibayar" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Simpan</button>
    </form>
</div>
<?= $this->endSection() ?>
