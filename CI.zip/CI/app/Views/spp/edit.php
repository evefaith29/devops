<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="container mt-5">
    <h2>Edit SPP</h2>
    <form action="/spp/update/<?= $spp['id'] ?>" method="post">
        <div class="form-group">
            <label for="tanggal">Tanggal</label>
            <input type="date" class="form-control" id="tanggal" name="tanggal" value="<?= $spp['tanggal'] ?>" required>
        </div>
        <div class="form-group">
            <label for="nama">Nama</label>
            <input type="text" class="form-control" id="nama" name="nama" value="<?= $spp['nama'] ?>" required>
        </div>
        <div class="form-group">
            <label for="nama_siswa">Nama Siswa</label>
            <input type="text" class="form-control" id="nama_siswa" name="nama_siswa" value="<?= $spp['nama_siswa'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jumlah_yang_harus_dibayar">Jumlah yang Harus Dibayar</label>
            <input type="number" class="form-control" id="jumlah_yang_harus_dibayar" name="jumlah_yang_harus_dibayar" value="<?= $spp['jumlah_yang_harus_dibayar'] ?>" required>
        </div>
        <div class="form-group">
            <label for="jumlah_dibayar">Jumlah Dibayar</label>
            <input type="number" class="form-control" id="jumlah_dibayar" name="jumlah_dibayar" value="<?= $spp['jumlah_dibayar'] ?>" required>
        </div>
        <button type="submit" class="btn btn-primary mt-3">Update</button>
    </form>
</div>
<?= $this->endSection() ?>
