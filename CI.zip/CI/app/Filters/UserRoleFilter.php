<?php

namespace App\Filters;

use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\Filters\FilterInterface;

class UserRoleFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        if (!$session->get('isLoggedIn')) {
            return redirect()->to('/login'); // Arahkan ke halaman login jika belum login
        }

        // Ambil role pengguna dari session
        $role = $session->get('role');

        // Memeriksa akses berdasarkan role
        if (in_array($role, $arguments)) {
            return; // Jika role ada dalam izin akses, lanjutkan
        }

        // Jika tidak memiliki akses, arahkan ke halaman yang tidak memiliki akses
        return redirect()->to('/no-access'); // Halaman tidak memiliki akses
    }

    public function after(RequestInterface $request, ResponseInterface $response)
    {
        // Do something here
    }
}
